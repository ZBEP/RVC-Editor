import sys
import os

def setup():
    app_dir = os.path.dirname(os.path.abspath(__file__))
    libs_dir = os.path.join(app_dir, "libs")
    
    if os.path.exists(libs_dir):
        if libs_dir not in sys.path:
            sys.path.insert(0, libs_dir)
        
        # Добавляем site-packages если есть
        site_packages = os.path.join(libs_dir, "site-packages")
        if os.path.exists(site_packages) and site_packages not in sys.path:
            sys.path.insert(0, site_packages)
        
        if sys.platform == "win32":
            dll_path = os.path.join(libs_dir, "PySide6")
            if os.path.exists(dll_path):
                os.add_dll_directory(dll_path)
        return True
    return False

_initialized = setup()

def check_deps():
    results = {}
    try:
        from PySide6 import __version__ as v
        results['PySide6'] = v
    except:
        results['PySide6'] = None
    try:
        import pyqtgraph
        results['pyqtgraph'] = pyqtgraph.__version__
    except:
        results['pyqtgraph'] = None
    return results