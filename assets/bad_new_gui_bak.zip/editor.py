import os
import numpy as np
import threading
import time
import json

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QComboBox,
    QFileDialog, QMessageBox, QMenu, QFrame
)
from PySide6.QtCore import Qt, QTimer, Signal, QObject
from PySide6.QtGui import QKeySequence, QShortcut

from lang import tr
from parts import PartGroup
from waveform import WaveformWidget
from history import HistoryManager

BLEND_VALUES = [0, 15, 30, 60, 120]
SNAP_THRESHOLD_PX = 10


class AudioSignal(QObject):
    update_ui = Signal()
    log_msg = Signal(str)


class EditorTab(QWidget):
    
    def __init__(self, parent, get_converter_fn, log_fn, set_progress_fn,
                 get_output_dir_fn, get_editor_file_fn, set_editor_file_fn,
                 get_preset_info_fn=None, initial_blend_mode=0):
        super().__init__(parent)
        
        self.get_converter = get_converter_fn
        self._log_fn = log_fn
        self.set_progress = set_progress_fn
        self.get_output_dir = get_output_dir_fn
        self.get_editor_file = get_editor_file_fn
        self.set_editor_file = set_editor_file_fn
        self.get_preset_info = get_preset_info_fn or (lambda: {})
        
        self.source_path = None
        self.source_audio = None
        self.result_audio = None
        self.source_audio_display = None
        self.result_audio_display = None
        
        self.sr = None
        self.total_samples = 0
        self.is_stereo = False
        
        self.zoom = 1.0
        self.offset = 0
        self.sel_start = None
        self.sel_end = None
        self.cursor_pos = None
        self.play_pos = None
        
        self.part_groups = []
        self.markers = []
        
        self._active_track = 'source'
        self._stream = None
        self._is_playing = False
        self._play_pos = 0
        self._play_start = 0
        self._play_end = 0
        self._stream_active = False
        self._is_converting = False
        self.blend_mode = initial_blend_mode
        self.history = None
        self.source_mode = "F"
        self.output_device = None
        self.output_devices = []
        
        self.signals = AudioSignal()
        self.signals.update_ui.connect(self._on_ui_update)
        self.signals.log_msg.connect(lambda m: self._log_fn(m))
        
        self._build()
        self._scan_devices()
        self._bind_shortcuts()
    
    def _bind_shortcuts(self):
        QShortcut(QKeySequence(Qt.Key_Space), self, self._toggle_play)
        QShortcut(QKeySequence(Qt.Key_I), self, self._hotkey_marker)
        QShortcut(QKeySequence(Qt.Key_R), self, self._convert)
        QShortcut(QKeySequence(Qt.Key_Delete), self, self._hotkey_delete)
        QShortcut(QKeySequence("Ctrl+Z"), self, self._undo)
        QShortcut(QKeySequence("Ctrl+Y"), self, self._redo)
        QShortcut(QKeySequence("Ctrl+Shift+Z"), self, self._redo)
        QShortcut(QKeySequence(Qt.Key_Left), self, lambda: self._move_cursor(-self._get_cursor_step()))
        QShortcut(QKeySequence(Qt.Key_Right), self, lambda: self._move_cursor(self._get_cursor_step()))
        for i in range(10):
            QShortcut(QKeySequence(str(i)), self, lambda n=i: self._process_number_key(n))
    
    def log(self, msg):
        self.signals.log_msg.emit(str(msg))
    
    def _on_ui_update(self):
        self._update_playhead()
        self._update_time()
        self._sync_play_button()
    
    def _build(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(5, 5, 5, 5)
        layout.setSpacing(5)
        
        # Top controls
        ctrl = QHBoxLayout()
        
        self.load_btn = QPushButton("📂")
        self.load_btn.setFixedWidth(32)
        self.load_btn.clicked.connect(self._load)
        ctrl.addWidget(self.load_btn)
        
        self.file_lbl = QLabel(tr("(file not selected)"))
        self.file_lbl.setStyleSheet("color: #6c7086;")
        self.file_lbl.setFixedWidth(150)
        ctrl.addWidget(self.file_lbl)
        
        self.save_btn = QPushButton("💾")
        self.save_btn.setFixedWidth(32)
        self.save_btn.clicked.connect(self._save_result)
        ctrl.addWidget(self.save_btn)
        
        sep1 = QFrame()
        sep1.setFrameShape(QFrame.VLine)
        sep1.setStyleSheet("background: #45475a;")
        ctrl.addWidget(sep1)
        
        self.play_btn = QPushButton("▶")
        self.play_btn.setFixedWidth(32)
        self.play_btn.clicked.connect(self._toggle_play)
        ctrl.addWidget(self.play_btn)
        
        self.active_lbl = QLabel(f"[{tr('Source')}]")
        self.active_lbl.setStyleSheet("color: #5dade2; font-weight: bold;")
        ctrl.addWidget(self.active_lbl)
        
        sep2 = QFrame()
        sep2.setFrameShape(QFrame.VLine)
        sep2.setStyleSheet("background: #45475a;")
        ctrl.addWidget(sep2)
        
        self.preset_lbl = QLabel("")
        self.preset_lbl.setStyleSheet("color: #6c7086;")
        ctrl.addWidget(self.preset_lbl)
        
        ctrl.addStretch()
        
        self.refresh_dev_btn = QPushButton("🔄")
        self.refresh_dev_btn.setFixedWidth(28)
        self.refresh_dev_btn.clicked.connect(self._rescan_devices)
        ctrl.addWidget(self.refresh_dev_btn)
        
        self.device_combo = QComboBox()
        self.device_combo.setFixedWidth(200)
        self.device_combo.currentIndexChanged.connect(self._on_device_change)
        ctrl.addWidget(self.device_combo)
        
        sep3 = QFrame()
        sep3.setFrameShape(QFrame.VLine)
        sep3.setStyleSheet("background: #45475a;")
        ctrl.addWidget(sep3)
        
        self.run_btn = QPushButton(tr("Run"))
        self.run_btn.setStyleSheet("background: #89b4fa; color: #1e1e2e; font-weight: bold;")
        self.run_btn.clicked.connect(self._convert)
        ctrl.addWidget(self.run_btn)
        
        layout.addLayout(ctrl)
        
        # Waveforms
        tracks = QVBoxLayout()
        tracks.setSpacing(3)
        
        # Result track
        result_row = QHBoxLayout()
        result_row.setSpacing(3)
        r_lbl = QLabel("R")
        r_lbl.setStyleSheet("color: #e74c3c; font-family: Consolas; font-size: 10px;")
        r_lbl.setFixedWidth(12)
        result_row.addWidget(r_lbl)
        self.result_wf = WaveformWidget(self, is_result=True, height=90)
        result_row.addWidget(self.result_wf, 1)
        tracks.addLayout(result_row)
        
        # Source track
        source_row = QHBoxLayout()
        source_row.setSpacing(3)
        s_lbl = QLabel("S")
        s_lbl.setStyleSheet("color: #5dade2; font-family: Consolas; font-size: 10px;")
        s_lbl.setFixedWidth(12)
        source_row.addWidget(s_lbl)
        self.source_wf = WaveformWidget(self, is_result=False, height=90)
        source_row.addWidget(self.source_wf, 1)
        tracks.addLayout(source_row)
        
        layout.addLayout(tracks, 1)
        
        # Bottom controls
        bottom = QHBoxLayout()
        
        self.source_mode_btn = QPushButton("F")
        self.source_mode_btn.setFixedWidth(24)
        self.source_mode_btn.clicked.connect(self._toggle_source_mode)
        bottom.addWidget(self.source_mode_btn)
        
        self.time_lbl = QLabel("00:00.000 / 00:00.000")
        self.time_lbl.setStyleSheet("font-family: Consolas;")
        bottom.addWidget(self.time_lbl)
        
        bottom.addStretch()
        
        self.sel_lbl = QLabel("")
        self.sel_lbl.setStyleSheet("color: #6c7086; font-family: Consolas;")
        bottom.addWidget(self.sel_lbl)
        
        bottom.addWidget(QLabel("Blend:"))
        
        self.blend_btns = {}
        for val in BLEND_VALUES:
            btn = QPushButton(str(val))
            btn.setFixedWidth(32)
            btn.setCheckable(True)
            btn.clicked.connect(lambda _, v=val: self._set_blend(v))
            self.blend_btns[val] = btn
            bottom.addWidget(btn)
        
        bottom.addWidget(QLabel(tr("ms")))
        
        layout.addLayout(bottom)
        
        self._update_blend_buttons()
    
    def _to_mono(self, audio):
        if audio is None:
            return None
        return audio.mean(axis=1).astype(np.float32) if len(audio.shape) > 1 else audio.astype(np.float32)
    
    def _set_blend(self, value):
        self.blend_mode = value
        self._update_blend_buttons()
    
    def _update_blend_buttons(self):
        for val, btn in self.blend_btns.items():
            btn.setChecked(val == self.blend_mode)
    
    def _toggle_source_mode(self):
        if not self.is_stereo:
            return
        modes = ["F", "L", "R"]
        idx = modes.index(self.source_mode) if self.source_mode in modes else 0
        self.source_mode = modes[(idx + 1) % 3]
        self.source_mode_btn.setText(self.source_mode)
    
    def _get_source_for_convert(self, start, end):
        data = self.source_audio[start:end].copy()
        if not self.is_stereo or self.source_mode == "F":
            return data
        if self.source_mode == "L":
            return data[:, 0]
        return data[:, 1]
    
    def _get_project_dir(self):
        if not self.source_path:
            return None
        name = os.path.splitext(os.path.basename(self.source_path))[0]
        return os.path.join(self.get_output_dir(), "editor", name)
    
    def _get_parts_dir(self):
        project_dir = self._get_project_dir()
        d = os.path.join(project_dir, "parts") if project_dir else os.path.join(self.get_output_dir(), "editor", "_temp", "parts")
        os.makedirs(d, exist_ok=True)
        return d
    
    def _init_history(self):
        project_dir = self._get_project_dir()
        if project_dir:
            os.makedirs(project_dir, exist_ok=True)
            self.history = HistoryManager(project_dir, self.sr or 44100)
    
    def _save_project(self):
        project_dir = self._get_project_dir()
        if not project_dir or self.source_audio is None:
            return
        
        os.makedirs(project_dir, exist_ok=True)
        import soundfile as sf
        
        if self.result_audio is not None:
            sf.write(os.path.join(project_dir, "result.wav"), self.result_audio, self.sr)
        
        data = {
            "markers": self.markers,
            "sel_start": self.sel_start,
            "sel_end": self.sel_end,
            "cursor_pos": self.cursor_pos,
            "zoom": self.zoom,
            "offset": self.offset,
            "active_track": self._active_track,
            "source_mode": self.source_mode,
            "parts": [g.to_dict() for g in self.part_groups]
        }
        
        with open(os.path.join(project_dir, "project.json"), 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2)
    
    def _load_project(self):
        project_dir = self._get_project_dir()
        if not project_dir:
            return False
        
        project_file = os.path.join(project_dir, "project.json")
        if not os.path.exists(project_file):
            return False
        
        try:
            import soundfile as sf
            
            with open(project_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            result_path = os.path.join(project_dir, "result.wav")
            if os.path.exists(result_path):
                result, _ = sf.read(result_path)
                self.result_audio = result.astype(np.float32)
                self.result_audio_display = self._to_mono(result)
            
            self.markers = data.get("markers", [])
            self.sel_start = data.get("sel_start")
            self.sel_end = data.get("sel_end")
            self.cursor_pos = data.get("cursor_pos", 0)
            self.zoom = data.get("zoom", 1.0)
            self.offset = data.get("offset", 0)
            self._active_track = data.get("active_track", "source")
            
            saved_mode = data.get("source_mode", "F")
            self.source_mode = saved_mode if self.is_stereo and saved_mode in ("F", "L", "R") else ("M" if not self.is_stereo else "F")
            self.source_mode_btn.setText(self.source_mode)
            
            parts_dir = self._get_parts_dir()
            for p in data.get("parts", []):
                versions = [os.path.join(parts_dir, v) for v in p["versions"]
                           if os.path.exists(os.path.join(parts_dir, v))]
                if not versions:
                    continue
                g = PartGroup(p["start"], p["end"], parts_dir, self.sr)
                g.id = p["id"]
                g.active_idx = min(p["active_idx"], len(versions) - 1)
                g.has_base = p["has_base"]
                g.versions = versions
                g.version_params = p.get("version_params", [None] * len(versions))
                while len(g.version_params) < len(versions):
                    g.version_params.append(None)
                self.part_groups.append(g)
            
            self.log(tr("Project loaded"))
            return True
        except Exception as e:
            self.log(f"{tr('Project load error:')} {e}")
            return False
    
    def _assign_levels(self):
        if not self.part_groups:
            return
        sorted_groups = sorted(self.part_groups, key=lambda g: (g.start, -(g.end - g.start)))
        level_ends = []
        for g in sorted_groups:
            placed = False
            for level, end in enumerate(level_ends):
                if g.start >= end:
                    g.level = level
                    level_ends[level] = g.end
                    placed = True
                    break
            if not placed:
                g.level = len(level_ends)
                level_ends.append(g.end)
    
    def _scan_devices(self):
        try:
            import sounddevice as sd
            self.output_devices = []
            for i, d in enumerate(sd.query_devices()):
                if d['max_output_channels'] > 0:
                    name = d['name'][:40]
                    if d['max_input_channels'] == 0 or not any(n == name for _, n in self.output_devices):
                        self.output_devices.append((i, name))
            
            self.device_combo.clear()
            self.device_combo.addItems([n for _, n in self.output_devices])
            
            if self.output_devices:
                try:
                    default = sd.query_devices(kind='output')
                    for i, (dev_id, name) in enumerate(self.output_devices):
                        if default['name'].startswith(name[:20]):
                            self.device_combo.setCurrentIndex(i)
                            self.output_device = dev_id
                            return
                except:
                    pass
                self.device_combo.setCurrentIndex(0)
                self.output_device = self.output_devices[0][0]
        except Exception as e:
            self.log(f"{tr('Device scan error:')} {e}")
    
    def _rescan_devices(self):
        import sounddevice as sd
        old_name = next((n for d, n in self.output_devices if d == self.output_device), "")
        try:
            sd._terminate()
            sd._initialize()
        except:
            pass
        self._scan_devices()
        for i, (d, n) in enumerate(self.output_devices):
            if n == old_name:
                self.device_combo.setCurrentIndex(i)
                self.output_device = d
                break
        if self._stream_active:
            self._restart_stream()
    
    def _on_device_change(self, idx):
        if 0 <= idx < len(self.output_devices):
            self.output_device = self.output_devices[idx][0]
            if self._stream_active:
                self._restart_stream()
    
    def on_tab_activated(self):
        saved = self.get_editor_file()
        if saved and os.path.exists(saved) and self.source_path != saved:
            self._load_file(saved)
        if self.sr and not self._stream_active:
            self._init_stream()
        self.update_preset_display()
    
    def on_tab_deactivated(self):
        self._is_playing = False
        self._stop_stream()
        self.play_btn.setText("▶")
        self.play_pos = None
        self._save_project()
    
    def cleanup(self):
        self._save_project()
        self._stop_stream()
    
    def update_preset_display(self):
        p = self.get_preset_info()
        if not p.get("model"):
            self.preset_lbl.setText(tr("(no model)"))
            return
        m = os.path.splitext(p["model"])[0]
        m = m[:10] + ".." if len(m) > 12 else m
        F0_SHORT = {"rmvpe": "RM", "mangio-crepe": "MC", "crepe": "CR"}
        f0 = F0_SHORT.get(p.get("f0_method", ""), "?")
        def fmt(v): return f"{v:.2f}".lstrip('0') or '0'
        parts = [f0, f"{p.get('pitch', 0):+d}", f"I{fmt(p.get('index_rate', .9))}",
                 f"P{fmt(p.get('protect', .33))}"]
        self.preset_lbl.setText(f"{m} | {' '.join(parts)}")
    
    def on_preset_loaded(self):
        self.update_preset_display()
        if self.source_audio is not None and not self._is_converting:
            self._convert()
    
    def _s2x(self, sample, width):
        if self.total_samples == 0:
            return 0
        return int((sample - self.offset) / (self.total_samples / self.zoom) * width)
    
    def _x2s(self, x, width):
        if self.total_samples == 0:
            return 0
        return int(self.offset + x / width * self.total_samples / self.zoom)
    
    def _clamp_offset(self):
        visible = int(self.total_samples / self.zoom)
        self.offset = max(0, min(self.total_samples - visible, self.offset))
    
    def _on_zoom(self, x, width, delta):
        if self.source_audio is None:
            return
        mouse_s = self._x2s(x, width)
        self.zoom = max(1.0, min(2000.0, self.zoom * (1.25 if delta > 0 else 0.8)))
        self.offset = int(mouse_s - (self.total_samples / self.zoom) * x / max(1, width))
        self._clamp_offset()
        self._redraw()
    
    def _on_scroll(self, delta):
        if self.source_audio is None:
            return
        self.offset += int(self.total_samples / self.zoom * 0.05) * (-1 if delta > 0 else 1)
        self._clamp_offset()
        self._redraw()
    
    def _on_click(self, x, width, is_result, shift=False):
        if self.source_audio is None:
            return
        self._active_track = 'result' if is_result else 'source'
        self._update_active_label()
        sample = max(0, min(self.total_samples - 1, self._x2s(x, width)))
        
        if shift and self.sel_start is not None:
            s1, s2 = sorted([self.sel_start, self.sel_end])
            anchor = s2 if abs(sample - s1) < abs(sample - s2) else s1
            self.sel_start, self.sel_end = (sample, anchor) if sample < anchor else (anchor, sample)
        else:
            self.sel_start = self.sel_end = self.cursor_pos = sample
        
        self._redraw()
        self._update_time()
    
    def _on_drag(self, x, width):
        if self.source_audio is None or self.sel_start is None:
            return
        sample = max(0, min(self.total_samples - 1, self._x2s(x, width)))
        self.sel_end = sample
        self._redraw()
        self._update_time()
    
    def _on_release(self, width):
        if self.sel_start is not None:
            if abs(self.sel_end - self.sel_start) < 100:
                self.cursor_pos = self._snap_to_points(self.sel_start, width)
                self.sel_start = self.sel_end = None
            else:
                s1, s2 = sorted([self.sel_start, self.sel_end])
                s1 = self._snap_to_points(s1, width)
                s2 = self._snap_to_points(s2, width)
                self.sel_start, self.sel_end = s1, s2
        self._redraw()
        self._update_time()
    
    def _on_double_click(self, x, width, is_result):
        if self.source_audio is None:
            return
        sample = self._x2s(x, width)
        
        if is_result:
            matching = [g for g in self.part_groups if g.start <= sample < g.end]
            if matching:
                smallest = min(matching, key=lambda g: g.size())
                self.sel_start, self.sel_end = smallest.start, smallest.end
                self._redraw()
                self._update_time()
                return
        else:
            sorted_markers = sorted([0] + self.markers + [self.total_samples])
            for i in range(len(sorted_markers) - 1):
                if sorted_markers[i] <= sample < sorted_markers[i + 1]:
                    self.sel_start = sorted_markers[i]
                    self.sel_end = sorted_markers[i + 1]
                    self._redraw()
                    self._update_time()
                    return
    
    def _snap_to_points(self, sample, width, snap_to_markers=True, snap_to_selection=False, exclude_part=None):
        if self.total_samples == 0 or width <= 0:
            return sample
        
        spp = self.total_samples / self.zoom / width
        threshold = max(1, int(SNAP_THRESHOLD_PX * spp))
        
        snap_points = []
        for g in self.part_groups:
            if g is not exclude_part:
                snap_points.extend([g.start, g.end])
        
        if snap_to_markers:
            snap_points.extend(self.markers)
        
        if snap_to_selection and self.sel_start is not None:
            snap_points.extend([self.sel_start, self.sel_end])
        
        best, best_dist = sample, threshold + 1
        for pt in snap_points:
            dist = abs(sample - pt)
            if dist < best_dist:
                best, best_dist = pt, dist
        
        return best if best_dist <= threshold else sample
    
    def _get_cursor_step(self):
        if self.total_samples == 0 or self.sr is None:
            return 0
        if self._is_playing:
            return int(self.sr * 1.0)
        visible = int(self.total_samples / self.zoom)
        return max(1, visible // 200)
    
    def _move_cursor(self, delta):
        if self.source_audio is None:
            return
        if self._is_playing:
            self._play_pos = max(self._play_start, min(self._play_end - 1, self._play_pos + delta))
            self.play_pos = self._play_pos
            self._update_playhead()
            self._update_time()
        else:
            pos = self.cursor_pos if self.cursor_pos is not None else 0
            pos = max(0, min(self.total_samples - 1, pos + delta))
            self.cursor_pos = pos
            self.sel_start = self.sel_end = None
            self._redraw()
            self._update_time()
    
    def _update_active_label(self):
        is_result = self._active_track == 'result'
        self.active_lbl.setText(f"[{tr('Result')}]" if is_result else f"[{tr('Source')}]")
        self.active_lbl.setStyleSheet(f"color: {'#e74c3c' if is_result else '#5dade2'}; font-weight: bold;")
    
    def _redraw(self):
        self.source_wf.update()
        self.result_wf.update()
    
    def _update_playhead(self):
        self.source_wf.update()
        self.result_wf.update()
    
    def _update_time(self):
        if not self.sr:
            return
        def fmt(s):
            sec = s / self.sr
            return f"{int(sec // 60):02d}:{sec % 60:06.3f}"
        
        current_pos = self._play_pos if self._is_playing else (self.cursor_pos or 0)
        self.time_lbl.setText(f"{fmt(current_pos)} / {fmt(self.total_samples)}")
        
        if self.sel_start is not None:
            s1, s2 = sorted([self.sel_start, self.sel_end])
            self.sel_lbl.setText(f"{tr('Selected:')} {(s2-s1)/self.sr:.2f}s")
        else:
            self.sel_lbl.setText("")
    
    def _load(self):
        path, _ = QFileDialog.getOpenFileName(self, tr("Load WAV"), "", "WAV Files (*.wav)")
        if path:
            self._load_file(path)
    
    def _load_file(self, path):
        if not os.path.exists(path):
            self.log(f"{tr('File not found:')} {path}")
            return False
        try:
            import soundfile as sf
            data, sr = sf.read(path)
            
            self.part_groups = []
            self.markers.clear()
            self.result_audio = None
            self.result_audio_display = None
            
            self.source_audio = data.astype(np.float32)
            self.is_stereo = len(data.shape) > 1
            self.source_audio_display = self._to_mono(data)
            
            self.source_mode = "M" if not self.is_stereo else "F"
            self.source_mode_btn.setText(self.source_mode)
            
            self.source_path = path
            self.sr = sr
            self.total_samples = len(self.source_audio_display)
            self.zoom, self.offset = 1.0, 0
            self.sel_start = self.sel_end = None
            self.cursor_pos = 0
            self._active_track = 'source'
            
            self._load_project()
            self._init_history()
            self._init_stream()
            self._redraw()
            self._update_active_label()
            self._update_time()
            self.update_preset_display()
            
            stereo = " [stereo]" if self.is_stereo else ""
            name = os.path.basename(path)
            self.file_lbl.setText(name[:18] + ('...' if len(name) > 18 else '') + stereo)
            self.file_lbl.setStyleSheet("color: #cdd6f4;")
            self.log(f"{tr('Loaded:')} {name} ({len(data)/sr:.1f}s, {sr}Hz{stereo})")
            
            self.set_editor_file(path)
            return True
        except Exception as e:
            self.log(f"{tr('Load error:')} {e}")
            return False
    
    def _save_result(self):
        if self.result_audio is None:
            self.log(tr("No result"))
            return
        
        project_dir = self._get_project_dir() or self.get_output_dir()
        preset = self.get_preset_info()
        model_name = os.path.splitext(preset["model"])[0] if preset.get("model") else ""
        source_name = os.path.splitext(os.path.basename(self.source_path))[0] if self.source_path else ""
        
        default_name = f"{model_name} {source_name}.wav" if model_name else f"{source_name}_converted.wav"
        
        path, _ = QFileDialog.getSaveFileName(self, tr("Save"), os.path.join(project_dir, default_name), "WAV Files (*.wav)")
        if path:
            try:
                import soundfile as sf
                sf.write(path, self.result_audio, self.sr)
                self.log(f"{tr('Saved:')} {os.path.basename(path)}")
            except Exception as e:
                self.log(f"{tr('Error:')} {e}")
    
    def _get_active_audio(self):
        if self._active_track == 'result' and self.result_audio_display is not None:
            return self.result_audio_display
        return self.source_audio_display
    
    def _init_stream(self):
        self._stop_stream()
        if self.sr is None:
            return
        try:
            import sounddevice as sd
            
            def callback(outdata, frames, time_info, status):
                if not self._is_playing:
                    outdata.fill(0)
                    return
                audio = self._get_active_audio()
                if audio is None or self._play_pos >= self._play_end:
                    outdata.fill(0)
                    self._is_playing = False
                    self._play_pos = self._play_start
                    return
                chunk = min(frames, self._play_end - self._play_pos)
                outdata[:chunk, 0] = audio[self._play_pos:self._play_pos + chunk]
                outdata[chunk:] = 0
                self._play_pos += chunk
                self.play_pos = self._play_pos
            
            self._stream = sd.OutputStream(
                samplerate=self.sr, channels=1, callback=callback,
                device=self.output_device, blocksize=512, latency='low'
            )
            self._stream.start()
            self._stream_active = True
            
            def updater():
                while self._stream_active:
                    if self._is_playing:
                        self.signals.update_ui.emit()
                    time.sleep(0.03)
            threading.Thread(target=updater, daemon=True).start()
        except Exception as e:
            self.log(f"{tr('Audio error:')} {e}")
    
    def _stop_stream(self):
        self._is_playing = False
        self._stream_active = False
        if self._stream:
            try:
                self._stream.stop()
                self._stream.close()
            except:
                pass
            self._stream = None
    
    def _restart_stream(self):
        was, pos = self._is_playing, self._play_pos
        self._init_stream()
        if was:
            self._play_pos = pos
            self._is_playing = True
    
    def _sync_play_button(self):
        if self._is_playing:
            self.play_btn.setText("⏸")
        else:
            self.play_btn.setText("▶")
            self.play_pos = None
            self._redraw()
    
    def _toggle_play(self):
        if self.source_audio_display is None:
            return
        if not self._stream_active:
            self._init_stream()
        if self._is_playing:
            self._is_playing = False
            self.play_btn.setText("▶")
            self.play_pos = None
            self._redraw()
        else:
            if self.sel_start is not None:
                start, end = sorted([self.sel_start, self.sel_end])
            else:
                start, end = self.cursor_pos or 0, self.total_samples
            if start < end:
                self._play_pos = self._play_start = start
                self._play_end = end
                self._is_playing = True
                self.play_btn.setText("⏸")
    
    def _switch_track_and_play(self, to_result, x, width):
        self._active_track = 'result' if to_result else 'source'
        self._update_active_label()
        if self.source_audio_display is None:
            return
        sample = max(0, min(self.total_samples - 1, self._x2s(x, width)))
        if not self._stream_active:
            self._init_stream()
        self._play_pos = self._play_start = sample
        self._play_end = self.total_samples
        self._is_playing = True
        self.play_btn.setText("⏸")
    
    def _find_group(self, start, end):
        for g in self.part_groups:
            if g.start == start and g.end == end:
                return g
        return None
    
    def _get_group_at(self, sample):
        matching = [g for g in self.part_groups if g.start <= sample < g.end]
        return max(matching, key=lambda g: g.level) if matching else None
    
    def _switch_version_at(self, sample, delta):
        g = self._get_group_at(sample)
        if g:
            self._switch_version_and_play(g, delta)
    
    def _switch_version_and_play(self, part, delta):
        if len(part.versions) <= 1:
            return
        
        prev_idx = part.active_idx
        part.active_idx = (part.active_idx + delta) % len(part.versions)
        self._apply_version(part)
        self._save_project()
        
        if prev_idx != part.active_idx and self.history:
            self.history.push({"type": "switch", "part_id": part.id, "prev_idx": prev_idx, "new_idx": part.active_idx})
        
        label = part.version_label(part.active_idx)
        params_str = part.format_params(part.active_idx)
        self.log(f"{label}: {params_str}" if params_str else label)
        
        self._active_track = 'result'
        self._update_active_label()
        
        if not self._stream_active:
            self._init_stream()
        
        pos = self.cursor_pos or 0
        if not (part.start <= pos < part.end):
            pos = part.start
        
        self._play_pos = self._play_start = pos
        self._play_end = self._calc_play_end(pos)
        self._is_playing = True
        self.play_btn.setText("⏸")
    
    def _calc_play_end(self, pos):
        if self.sel_start is not None:
            s1, s2 = sorted([self.sel_start, self.sel_end])
            if s1 <= pos < s2:
                return s2
        return self.total_samples
    
    def _write_audio(self, data, start, fade_ms=0):
        if data is None or len(data) == 0:
            return
        
        write_len = min(len(data), self.total_samples - start)
        if write_len <= 0:
            return
        
        if fade_ms == 0 or write_len < 200 or self.result_audio is None:
            self.result_audio[start:start + write_len] = data[:write_len]
            self.result_audio_display[start:start + write_len] = data[:write_len]
            return
        
        fade_samples = min(int(self.sr * fade_ms / 1000), write_len // 4)
        fade_samples = max(20, fade_samples)
        
        result = data[:write_len].copy()
        
        old_left = self.result_audio[start:start + fade_samples].copy()
        if np.any(np.abs(old_left) > 0.0001):
            curve = np.linspace(0, 1, fade_samples, dtype=np.float32)
            result[:fade_samples] = old_left * (1 - curve) + result[:fade_samples] * curve
        
        end = start + write_len
        old_right = self.result_audio[end - fade_samples:end].copy()
        if np.any(np.abs(old_right) > 0.0001):
            curve = np.linspace(1, 0, fade_samples, dtype=np.float32)
            result[-fade_samples:] = result[-fade_samples:] * curve + old_right * (1 - curve)
        
        self.result_audio[start:end] = result
        self.result_audio_display[start:end] = result
    
    def _apply_version(self, group, preserve_nested=False):
        data = group.get_data()
        if data is None:
            return
        
        max_len = group.end - group.start
        write_len = min(len(data), max_len)
        if write_len <= 0:
            self._redraw()
            return
        
        write_data = data[:write_len]
        is_base = group.has_base and group.active_idx == 0
        use_fade = self.blend_mode if (self.blend_mode > 0 and not is_base and group.has_base) else 0
        
        if use_fade > 0:
            base_data = group.get_base_data()
            if base_data is not None:
                base_len = min(len(base_data), max_len)
                self.result_audio[group.start:group.start + base_len] = base_data[:base_len]
                self.result_audio_display[group.start:group.start + base_len] = base_data[:base_len]
        
        self._write_audio(write_data, group.start, fade_ms=use_fade)
        self._redraw()
    
    def _find_part_by_id(self, part_id):
        for g in self.part_groups:
            if g.id == part_id:
                return g
        return None
    
    def _hotkey_marker(self):
        if self.source_audio is None:
            return
        
        if self.sel_start is not None and abs(self.sel_end - self.sel_start) > 100:
            s1, s2 = sorted([self.sel_start, self.sel_end])
            added = 0
            for s in [s1, s2]:
                if s not in self.markers and 0 < s < self.total_samples:
                    self.markers.append(s)
                    added += 1
            if added:
                self.markers.sort()
                self._save_project()
                if self.history:
                    for s in [s1, s2]:
                        if 0 < s < self.total_samples:
                            self.history.push({"type": "add_marker", "sample": s})
                self._redraw()
            return
        
        if self.cursor_pos is not None and self.cursor_pos not in self.markers:
            self.markers.append(self.cursor_pos)
            self.markers.sort()
            self._save_project()
            if self.history:
                self.history.push({"type": "add_marker", "sample": self.cursor_pos})
            self.log(f"{tr('Marker:')} {self.cursor_pos/self.sr:.2f}s")
            self._redraw()
    
    def _hotkey_delete(self):
        if self.source_audio is None or not self.part_groups:
            return
        
        pos = self.cursor_pos or 0
        matching = [g for g in self.part_groups if g.start <= pos < g.end]
        if not matching:
            return
        
        part = min(matching, key=lambda g: g.size())
        
        if part.has_base and part.active_idx == 0:
            return
        if len(part.versions) <= 1:
            return
        
        idx = part.active_idx
        path = part.versions[idx]
        params = part.version_params[idx] if idx < len(part.version_params) else None
        prev_active = part.active_idx
        
        trash_path = self.history.move_to_trash(path) if self.history else None
        if not trash_path:
            try:
                os.remove(path)
            except:
                pass
        
        part.versions.pop(idx)
        part.version_params.pop(idx)
        part.active_idx = min(idx, len(part.versions) - 1)
        
        if part.has_base and len(part.versions) == 1:
            base_data = part.get_base_data()
            if base_data is not None:
                exp_len = part.end - part.start
                if len(base_data) != exp_len:
                    tmp = np.zeros(exp_len, dtype=np.float32)
                    tmp[:min(len(base_data), exp_len)] = base_data[:exp_len]
                    base_data = tmp
                self.result_audio[part.start:part.end] = base_data
                self.result_audio_display[part.start:part.end] = base_data
            
            part.cleanup()
            self.part_groups.remove(part)
            self.log(tr("Part deleted, data restored"))
        else:
            self._apply_version(part)
            label = part.version_label(part.active_idx)
            self.log(f"{tr('Version deleted')} → {label}")
        
        if self.history and trash_path:
            self.history.push({"type": "delete_ver", "part_id": part.id, "idx": idx, "orig_path": path,
                              "trash_path": trash_path, "params": params, "prev_active_idx": prev_active,
                              "new_active_idx": part.active_idx})
        
        self._save_project()
        self._redraw()
        self._play_after_action(pos, part.end if part in self.part_groups else self.total_samples)
    
    def _play_after_action(self, pos, end):
        self._active_track = 'result'
        self._update_active_label()
        if not self._stream_active:
            self._init_stream()
        self._play_pos = self._play_start = pos
        self._play_end = end
        self._is_playing = True
        self.play_btn.setText("⏸")
    
    def _process_number_key(self, num):
        if self.source_audio is None or not self.part_groups:
            return
        
        pos = self.cursor_pos or 0
        matching = [g for g in self.part_groups if g.start <= pos < g.end]
        if not matching:
            return
        
        part = min(matching, key=lambda g: g.size())
        target_idx = 0 if num == 0 and part.has_base else (num if part.has_base else num - 1)
        
        if not (0 <= target_idx < len(part.versions)):
            return
        
        prev_idx = part.active_idx
        if prev_idx == target_idx:
            return
        
        part.active_idx = target_idx
        self._apply_version(part)
        self._save_project()
        
        if self.history:
            self.history.push({"type": "switch", "part_id": part.id, "prev_idx": prev_idx, "new_idx": target_idx})
        
        self.log(part.version_label(part.active_idx))
        
        self._active_track = 'result'
        self._update_active_label()
        if not self._stream_active:
            self._init_stream()
        self._play_pos = self._play_start = pos
        self._play_end = self._calc_play_end(pos)
        self._is_playing = True
        self.play_btn.setText("⏸")
    
    def _show_marker_menu(self, pos, idx):
        menu = QMenu(self)
        menu.addAction(f"{tr('Marker:')} {self.markers[idx]/self.sr:.2f}s").setEnabled(False)
        menu.addSeparator()
        menu.addAction(tr("Delete"), lambda: self._remove_marker(idx))
        if len(self.markers) > 1:
            menu.addAction(tr("Delete all markers"), self._clear_markers)
        menu.exec(pos)
    
    def _remove_marker(self, idx):
        if not (0 <= idx < len(self.markers)):
            return
        sample = self.markers.pop(idx)
        self._save_project()
        if self.history:
            self.history.push({"type": "rm_marker", "sample": sample, "idx": idx})
        self._redraw()
    
    def _clear_markers(self):
        if not self.markers:
            return
        old = self.markers[:]
        self.markers.clear()
        self._save_project()
        if self.history:
            self.history.push({"type": "clear_markers", "markers": old})
        self._redraw()
    
    def _show_part_menu(self, pos, part):
        menu = QMenu(self)
        dur = (part.end - part.start) / self.sr
        menu.addAction(f"{part.start/self.sr:.1f}s - {part.end/self.sr:.1f}s ({dur:.2f}s)").setEnabled(False)
        menu.addSeparator()
        
        for i in range(len(part.versions)):
            lbl = part.version_label(i)
            params_str = part.format_params(i)
            if params_str:
                lbl = f"{lbl}: {params_str}"
            prefix = "● " if i == part.active_idx else "  "
            menu.addAction(f"{prefix}{lbl}", lambda idx=i, p=part: self._set_version(p, idx))
        
        if len(part.versions) > 1:
            menu.addSeparator()
            if not (part.has_base and part.active_idx == 0):
                menu.addAction(tr("Delete current version"), lambda: self._delete_version(part))
            menu.addAction(tr("Keep only current"), lambda: self._delete_others(part))
        
        menu.addSeparator()
        menu.addAction(tr("Delete part (restore)"), lambda: self._delete_part(part))
        
        if len(self.part_groups) > 1:
            menu.addSeparator()
            menu.addAction(tr("Flatten to single file"), self._flatten_parts)
        
        menu.exec(pos)
    
    def _set_version(self, part, idx):
        if idx < 0 or idx >= len(part.versions):
            return
        prev_idx = part.active_idx
        if prev_idx == idx:
            return
        part.active_idx = idx
        self._apply_version(part)
        self._save_project()
        if self.history:
            self.history.push({"type": "switch", "part_id": part.id, "prev_idx": prev_idx, "new_idx": idx})
    
    def _delete_version(self, part):
        if len(part.versions) <= 1 or (part.has_base and part.active_idx == 0):
            return
        idx = part.active_idx
        path = part.versions[idx]
        trash_path = self.history.move_to_trash(path) if self.history else None
        if not trash_path:
            try:
                os.remove(path)
            except:
                pass
        part.versions.pop(idx)
        part.version_params.pop(idx)
        part.active_idx = min(idx, len(part.versions) - 1)
        self._apply_version(part)
        self._save_project()
        if self.history and trash_path:
            self.history.push({"type": "delete_ver", "part_id": part.id, "idx": idx, "trash_path": trash_path})
        self._redraw()
    
    def _delete_others(self, part):
        if len(part.versions) <= 1:
            return
        keep = part.versions[part.active_idx]
        keep_params = part.version_params[part.active_idx]
        for p in part.versions:
            if p != keep:
                if self.history:
                    self.history.move_to_trash(p)
                else:
                    try:
                        os.remove(p)
                    except:
                        pass
        part.versions = [keep]
        part.version_params = [keep_params]
        part.active_idx = 0
        part.has_base = False
        self._save_project()
        self._redraw()
    
    def _delete_part(self, part):
        if part.has_base:
            base_data = part.get_base_data()
            if base_data is not None:
                exp_len = part.end - part.start
                if len(base_data) != exp_len:
                    tmp = np.zeros(exp_len, dtype=np.float32)
                    tmp[:min(len(base_data), exp_len)] = base_data[:exp_len]
                    base_data = tmp
                self.result_audio[part.start:part.end] = base_data
                self.result_audio_display[part.start:part.end] = base_data
        
        for p in part.versions:
            if self.history:
                self.history.move_to_trash(p)
            else:
                try:
                    os.remove(p)
                except:
                    pass
        
        if part in self.part_groups:
            self.part_groups.remove(part)
        self._save_project()
        self._redraw()
    
    def _flatten_parts(self):
        if not self.part_groups:
            return
        for part in list(self.part_groups):
            for p in part.versions:
                if self.history:
                    self.history.move_to_trash(p)
                else:
                    try:
                        os.remove(p)
                    except:
                        pass
        self.part_groups.clear()
        self._save_project()
        self._redraw()
    
    def _undo(self):
        if not self.history or not self.history.can_undo():
            return
        op = self.history.undo()
        if not op:
            return
        
        op_type = op.get("type", "")
        
        if op_type == "switch":
            part = self._find_part_by_id(op["part_id"])
            if part:
                part.active_idx = op["prev_idx"]
                self._apply_version(part)
        elif op_type == "add_marker":
            if op["sample"] in self.markers:
                self.markers.remove(op["sample"])
        elif op_type == "rm_marker":
            if op["sample"] not in self.markers:
                self.markers.append(op["sample"])
                self.markers.sort()
        elif op_type == "clear_markers":
            self.markers = op.get("markers", [])[:]
        elif op_type == "move_marker":
            if op["new_pos"] in self.markers:
                self.markers.remove(op["new_pos"])
            if op["old_pos"] not in self.markers:
                self.markers.append(op["old_pos"])
                self.markers.sort()
        elif op_type == "resize_part":
            part = self._find_part_by_id(op["part_id"])
            if part:
                part.start = op["old_start"]
                part.end = op["old_end"]
        
        self._redraw()
        self._save_project()
        self.log(f"↶ Undo: {op_type}")
    
    def _redo(self):
        if not self.history or not self.history.can_redo():
            return
        op = self.history.redo()
        if not op:
            return
        
        op_type = op.get("type", "")
        
        if op_type == "switch":
            part = self._find_part_by_id(op["part_id"])
            if part:
                part.active_idx = op["new_idx"]
                self._apply_version(part)
        elif op_type == "add_marker":
            if op["sample"] not in self.markers:
                self.markers.append(op["sample"])
                self.markers.sort()
        elif op_type == "rm_marker":
            if op["sample"] in self.markers:
                self.markers.remove(op["sample"])
        elif op_type == "clear_markers":
            self.markers.clear()
        elif op_type == "move_marker":
            if op["old_pos"] in self.markers:
                self.markers.remove(op["old_pos"])
            if op["new_pos"] not in self.markers:
                self.markers.append(op["new_pos"])
                self.markers.sort()
        elif op_type == "resize_part":
            part = self._find_part_by_id(op["part_id"])
            if part:
                part.start = op["new_start"]
                part.end = op["new_end"]
        
        self._redraw()
        self._save_project()
        self.log(f"↷ Redo: {op_type}")
    
    def _convert(self):
        if self.source_audio is None:
            self.log(tr("Load file first"))
            return
        
        if self._is_converting:
            self.log(tr("Conversion in progress"))
            return
        
        has_sel = self.sel_start is not None and abs(self.sel_end - self.sel_start) > 100
        
        if not has_sel and self.result_audio is not None:
            if QMessageBox.question(self, tr("Confirm"), tr("No selection. Convert entire file?")) != QMessageBox.Yes:
                return
        
        def work():
            self._is_converting = True
            try:
                conv, params = self.get_converter()
                if not conv:
                    self.log(tr("Converter not ready"))
                    return
                
                start, end = sorted([self.sel_start, self.sel_end]) if has_sel else (0, self.total_samples)
                if end - start < 1000:
                    self.log(tr("Fragment too short"))
                    return
                
                import soundfile as sf
                project_dir = self._get_project_dir()
                tmp_dir = project_dir if project_dir else self.get_output_dir()
                if project_dir:
                    os.makedirs(project_dir, exist_ok=True)
                
                tmp_in = os.path.join(tmp_dir, "_temp_in.wav")
                tmp_out = os.path.join(tmp_dir, "_temp_out.wav")
                
                # ВАЖНО: используем source_audio, НЕ source_audio_display!
                sf.write(tmp_in, self._get_source_for_convert(start, end), self.sr)
                
                self.log(f"{tr('Converting')} {(end-start)/self.sr:.2f}s...")
                self.set_progress(30, tr("Conversion..."))
                
                if conv.convert(tmp_in, tmp_out, **params) and os.path.exists(tmp_out):
                    converted, csr = sf.read(tmp_out)
                    converted = converted.astype(np.float32)
                    
                    if csr != self.sr:
                        import librosa
                        converted = librosa.resample(converted, orig_sr=csr, target_sr=self.sr)
                    
                    if len(converted.shape) > 1:
                        converted = converted.mean(axis=1).astype(np.float32)
                    
                    exp_len = end - start
                    write_len = min(len(converted), exp_len)
                    write_data = converted[:write_len]
                    
                    first_convert = self.result_audio is None
                    
                    if self.result_audio is None or len(self.result_audio) != self.total_samples:
                        self.result_audio = np.zeros(self.total_samples, dtype=np.float32)
                        self.result_audio_display = np.zeros(self.total_samples, dtype=np.float32)
                    
                    existing_group = self._find_group(start, end)
                    was_new = existing_group is None
                    
                    if was_new:
                        group = PartGroup(start, end, self._get_parts_dir(), self.sr)
                        self.part_groups.append(group)
                        
                        if not first_convert:
                            existing = self.result_audio[start:end].copy()
                            if np.any(existing != 0):
                                group.set_base(existing)
                    else:
                        group = existing_group
                    
                    self._write_audio(write_data, start, fade_ms=self.blend_mode)
                    
                    version_params = {
                        "pitch": params.get("pitch", 0),
                        "f0_method": params.get("f0_method", "rmvpe"),
                        "index_rate": params.get("index_rate", 0.9),
                        "filter_radius": params.get("filter_radius", 3),
                        "protect": params.get("protect", 0.33),
                        "crepe_hop_length": params.get("crepe_hop_length", 120),
                        "source_mode": self.source_mode
                    }
                    group.add_version(write_data, version_params)
                    
                    if self.history:
                        self.history.push({"type": "convert", "part_id": group.id, "start": start, "end": end, "was_new": was_new})
                    
                    self._active_track = 'result'
                    self.signals.update_ui.emit()
                    self._save_project()
                    
                    ver_info = f" ({group.version_label(group.active_idx)})" if group.version_count() > 1 or group.has_base else ""
                    self.set_progress(100, f"✓ {tr('Done')}")
                    self.log(f"✓ {tr('Done')}{ver_info}")
                else:
                    self.set_progress(0, tr("Error"))
                    self.log(tr("Conversion error"))
                
                for f in [tmp_in, tmp_out]:
                    try:
                        os.remove(f)
                    except:
                        pass
            except Exception as ex:
                import traceback
                traceback.print_exc()
                self.log(f"{tr('Error:')} {ex}")
                self.set_progress(0, tr("Error"))
            finally:
                self._is_converting = False
        
        threading.Thread(target=work, daemon=True).start()