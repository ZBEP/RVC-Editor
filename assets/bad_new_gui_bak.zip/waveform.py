import numpy as np
from PySide6.QtWidgets import QWidget, QVBoxLayout
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QPainter, QColor, QPen, QBrush, QFont, QFontMetrics
from lang import tr

MARKER_HANDLE_H = 12
PART_ROW_H = 11
PART_TOP_M = 2
SNAP_PX = 10


class WaveformWidget(QWidget):
    def __init__(self, editor, is_result=False, height=90, parent=None):
        super().__init__(parent)
        self.editor = editor
        self.is_result = is_result
        self.color = QColor('#e74c3c') if is_result else QColor('#5dade2')
        self.setMinimumHeight(height)
        self.setMaximumHeight(height + 30)
        self.setMouseTracking(True)
        
        self._drag_mode = None
        self._drag_marker = None
        self._drag_part_edge = None
        self._drag_start_data = None
    
    def get_audio(self):
        return self.editor.result_audio_display if self.is_result else self.editor.source_audio_display
    
    def _s2x(self, sample):
        ed = self.editor
        if ed.total_samples == 0:
            return 0
        return int((sample - ed.offset) / (ed.total_samples / ed.zoom) * self.width())
    
    def _x2s(self, x):
        ed = self.editor
        if ed.total_samples == 0:
            return 0
        return int(ed.offset + x / self.width() * ed.total_samples / ed.zoom)
    
    def _parts_zone_h(self):
        if not self.is_result or not self.editor.part_groups:
            return 0
        max_lvl = max((g.level for g in self.editor.part_groups), default=0)
        return PART_TOP_M + (max_lvl + 1) * PART_ROW_H
    
    def _find_marker_at(self, x, thresh=8):
        for i, m in enumerate(self.editor.markers):
            if abs(x - self._s2x(m)) <= thresh:
                return i
        return None
    
    def _find_part_at(self, x, y):
        if not self.is_result:
            return None
        sample = self._x2s(x)
        for g in self.editor.part_groups:
            y1 = PART_TOP_M + g.level * PART_ROW_H
            if y1 <= y < y1 + PART_ROW_H and g.start <= sample < g.end:
                return g
        return None
    
    def _find_part_edge(self, x, y, thresh=6):
        if not self.is_result:
            return None
        for g in self.editor.part_groups:
            y1 = PART_TOP_M + g.level * PART_ROW_H
            if not (y1 <= y < y1 + PART_ROW_H):
                continue
            if abs(x - self._s2x(g.start)) <= thresh:
                return (g, 'start')
            if abs(x - self._s2x(g.end)) <= thresh:
                return (g, 'end')
        return None
    
    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        ed = self.editor
        
        p.fillRect(0, 0, w, h, QColor('#1e1e2e'))
        
        audio = self.get_audio()
        if audio is None or ed.total_samples == 0:
            p.setPen(QColor('#666'))
            p.drawText(w // 2 - 40, h // 2, tr("Result") if self.is_result else tr("Load WAV"))
            return
        
        mid = h // 2
        
        # Выделение
        if ed.sel_start is not None:
            x1, x2 = self._s2x(min(ed.sel_start, ed.sel_end)), self._s2x(max(ed.sel_start, ed.sel_end))
            p.fillRect(x1, 0, x2 - x1, h, QColor(45, 74, 111, 150))
            p.setPen(QPen(QColor('#4a7ab0'), 1))
            p.drawRect(x1, 0, x2 - x1, h)
        
        # Waveform
        visible = ed.total_samples / ed.zoom
        spp = visible / max(1, w)
        p.setPen(QPen(self.color, 1))
        
        for x in range(w):
            s0 = int(ed.offset + x * spp)
            if s0 >= len(audio):
                break
            s1 = min(int(ed.offset + (x + 1) * spp), len(audio))
            chunk = audio[s0:s1]
            if len(chunk):
                amp = int(np.max(np.abs(chunk)) * mid * 0.9)
                p.drawLine(x, mid - amp, x, mid + amp)
        
        p.setPen(QPen(QColor('#444'), 1))
        p.drawLine(0, mid, w, mid)
        
        # Маркеры
        if not self.is_result:
            for i, m in enumerate(ed.markers):
                mx = self._s2x(m)
                if 0 <= mx <= w:
                    p.setPen(QPen(QColor('#ff9800'), 2, Qt.DashDotLine))
                    p.drawLine(mx, 0, mx, h)
                    p.fillRect(mx - 4, 0, 8, MARKER_HANDLE_H, QColor('#ff9800'))
        
        # Части
        if self.is_result and ed.part_groups:
            ed._assign_levels()
            for g in ed.part_groups:
                x1, x2 = max(0, self._s2x(g.start)), min(w, self._s2x(g.end))
                if x2 < 0 or x1 > w:
                    continue
                y1 = PART_TOP_M + g.level * PART_ROW_H
                y2 = y1 + PART_ROW_H - 2
                
                if g.has_base and g.active_idx == 0:
                    fill = QColor('#566573')
                elif len(g.versions) > (2 if g.has_base else 1):
                    fill = QColor('#9b59b6')
                else:
                    fill = QColor('#7f8c8d')
                
                p.fillRect(x1, y1, x2 - x1, y2 - y1, fill)
                p.setPen(QPen(fill.darker(120), 1))
                p.drawRect(x1, y1, x2 - x1, y2 - y1)
                
                if x2 - x1 > 30:
                    txt = tr("base") if (g.has_base and g.active_idx == 0) else (
                        f"{g.active_idx}/{len(g.versions)-1}" if g.has_base else 
                        (f"{g.active_idx+1}/{len(g.versions)}" if len(g.versions) > 1 else ""))
                    if txt:
                        p.setPen(QColor('#fff'))
                        p.setFont(QFont('Consolas', 7))
                        p.drawText(x1, y1, x2 - x1, y2 - y1, Qt.AlignCenter, txt)
        
        # Границы частей
        drawn = set()
        for g in ed.part_groups:
            for b in (g.start, g.end):
                if b not in drawn:
                    drawn.add(b)
                    bx = self._s2x(b)
                    if 0 <= bx <= w:
                        p.setPen(QPen(QColor('#8e44ad'), 1, Qt.DotLine))
                        p.drawLine(bx, 0, bx, h)
        
        # Курсор
        if ed.cursor_pos is not None:
            cx = self._s2x(ed.cursor_pos)
            if 0 <= cx <= w:
                p.setPen(QPen(QColor('#ffff00'), 1, Qt.DashLine))
                p.drawLine(cx, 0, cx, h)
        
        # Playhead
        if ed.play_pos is not None:
            px = self._s2x(ed.play_pos)
            if 0 <= px <= w:
                p.setPen(QPen(QColor('#00ff00'), 2))
                p.drawLine(px, 0, px, h)
    
    def mousePressEvent(self, e):
        ed = self.editor
        x, y = e.pos().x(), e.pos().y()
        
        if e.button() == Qt.RightButton:
            if not self.is_result and y < MARKER_HANDLE_H:
                idx = self._find_marker_at(x)
                if idx is not None:
                    ed._show_marker_menu(e.globalPos(), idx)
                    return
            if y < self._parts_zone_h():
                part = self._find_part_at(x, y)
                if part:
                    ed._show_part_menu(e.globalPos(), part)
                    return
            ed._switch_track_and_play(self.is_result, x, self.width())
            return
        
        # Границы частей
        if self.is_result:
            edge = self._find_part_edge(x, y)
            if edge:
                self._drag_part_edge = edge
                self._drag_start_data = {"old_start": edge[0].start, "old_end": edge[0].end}
                return
        
        # Маркеры
        if not self.is_result and y < MARKER_HANDLE_H:
            idx = self._find_marker_at(x)
            if idx is not None:
                self._drag_marker = idx
                self._drag_start_data = {"old_pos": ed.markers[idx]}
                return
        
        ed._on_click(x, self.width(), self.is_result, bool(e.modifiers() & Qt.ShiftModifier))
        self._drag_mode = 'select'
    
    def mouseMoveEvent(self, e):
        ed = self.editor
        x, y = e.pos().x(), e.pos().y()
        w = self.width()
        
        if self._drag_part_edge:
            part, edge = self._drag_part_edge
            sample = max(0, min(ed.total_samples - 1, self._x2s(x)))
            if edge == 'start':
                part.start = max(0, min(sample, part.end - 2000))
            else:
                part.end = min(ed.total_samples, max(sample, part.start + 2000))
            self.update()
            return
        
        if self._drag_marker is not None:
            sample = max(0, min(ed.total_samples - 1, self._x2s(x)))
            ed.markers[self._drag_marker] = sample
            self.update()
            return
        
        if self._drag_mode:
            ed._on_drag(x, w)
            return
        
        # Курсор
        if self.is_result and self._find_part_edge(x, y):
            self.setCursor(Qt.SizeHorCursor)
        elif not self.is_result and y < MARKER_HANDLE_H and self._find_marker_at(x) is not None:
            self.setCursor(Qt.SizeHorCursor)
        elif y < self._parts_zone_h() and self._find_part_at(x, y):
            self.setCursor(Qt.PointingHandCursor)
        else:
            self.setCursor(Qt.ArrowCursor)
    
    def mouseReleaseEvent(self, e):
        ed = self.editor
        x = e.pos().x()
        w = self.width()
        
        if self._drag_part_edge:
            part, edge = self._drag_part_edge
            sample = ed._snap_to_points(self._x2s(x), w, exclude_part=part)
            if edge == 'start':
                part.start = max(0, min(sample, part.end - 2000))
            else:
                part.end = min(ed.total_samples, max(sample, part.start + 2000))
            
            if ed.history and self._drag_start_data:
                if part.start != self._drag_start_data["old_start"] or part.end != self._drag_start_data["old_end"]:
                    ed.history.push({"type": "resize_part", "part_id": part.id,
                                     "old_start": self._drag_start_data["old_start"],
                                     "old_end": self._drag_start_data["old_end"],
                                     "new_start": part.start, "new_end": part.end})
            self._drag_part_edge = None
            self._drag_start_data = None
            ed._redraw()
            ed._save_project()
            return
        
        if self._drag_marker is not None:
            sample = ed._snap_to_points(self._x2s(x), w, snap_to_markers=False)
            ed.markers[self._drag_marker] = sample
            ed.markers.sort()
            if ed.history and self._drag_start_data:
                if sample != self._drag_start_data["old_pos"]:
                    ed.history.push({"type": "move_marker", "old_pos": self._drag_start_data["old_pos"], "new_pos": sample})
            self._drag_marker = None
            self._drag_start_data = None
            ed._redraw()
            ed._save_project()
            return
        
        if self._drag_mode:
            self._drag_mode = None
            ed._on_release(w)
    
    def mouseDoubleClickEvent(self, e):
        self.editor._on_double_click(e.pos().x(), self.width(), self.is_result)
    
    def wheelEvent(self, e):
        ed = self.editor
        x, y = e.position().x(), e.position().y()
        delta = e.angleDelta().y()
        mods = e.modifiers()
        
        if mods & Qt.ControlModifier:
            ed._on_zoom(x, self.width(), delta)
        elif mods & Qt.ShiftModifier:
            ed._on_scroll(delta)
        elif self.is_result:
            if y < self._parts_zone_h():
                part = self._find_part_at(x, y)
                if part:
                    ed._switch_version_and_play(part, 1 if delta > 0 else -1)
            else:
                sample = self._x2s(x)
                ed._switch_version_at(sample, 1 if delta > 0 else -1)