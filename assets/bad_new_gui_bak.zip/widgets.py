from PySide6.QtWidgets import QWidget, QHBoxLayout, QSlider, QLineEdit, QLabel
from PySide6.QtCore import Qt, Signal, QTimer


class ScaleWithEntry(QWidget):
    valueChanged = Signal(float)
    
    def __init__(self, get_val, set_val, from_, to, step=1, entry_width=50, scale_length=120, parent=None):
        super().__init__(parent)
        self.get_val, self.set_val = get_val, set_val
        self.from_, self.to, self.step = from_, to, step
        self.is_float = isinstance(step, float) or step < 1
        
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(5)
        
        self.slider = QSlider(Qt.Horizontal)
        self.slider.setFixedWidth(scale_length)
        mult = 100 if self.is_float else 1
        self.slider.setRange(int(from_ * mult), int(to * mult))
        self.slider.valueChanged.connect(self._on_slider)
        layout.addWidget(self.slider)
        
        self.entry = QLineEdit()
        self.entry.setFixedWidth(entry_width)
        self.entry.setAlignment(Qt.AlignCenter)
        self.entry.setStyleSheet("background: #2d2d3d; color: #fff; border: 1px solid #444; border-radius: 3px;")
        self.entry.returnPressed.connect(self._on_entry)
        self.entry.editingFinished.connect(self._on_entry)
        layout.addWidget(self.entry)
        
        self.refresh()
    
    def _on_slider(self, v):
        val = v / 100.0 if self.is_float else v
        self.set_val(val)
        self._update_entry(val)
        self.valueChanged.emit(val)
    
    def _on_entry(self):
        try:
            val = float(self.entry.text())
            val = max(self.from_, min(self.to, val))
            if not self.is_float:
                val = round(val)
            self.set_val(val)
            self._update_slider(val)
            self.valueChanged.emit(val)
        except:
            self.refresh()
    
    def _update_entry(self, val):
        self.entry.setText(f"{val:.2f}" if self.is_float else str(int(val)))
    
    def _update_slider(self, val):
        self.slider.blockSignals(True)
        self.slider.setValue(int(val * 100) if self.is_float else int(val))
        self.slider.blockSignals(False)
    
    def refresh(self):
        val = self.get_val()
        self._update_entry(val)
        self._update_slider(val)


class ResettableLabel(QLabel):
    def __init__(self, text, get_val, set_val, default, on_reset=None, parent=None):
        super().__init__(text, parent)
        self.get_val, self.set_val, self.default, self.on_reset = get_val, set_val, default, on_reset
        self.setCursor(Qt.PointingHandCursor)
        self._normal_style = "color: #ccc;"
        self._hover_style = "color: #66b3ff;"
        self.setStyleSheet(self._normal_style)
    
    def enterEvent(self, e):
        self.setStyleSheet(self._hover_style)
    
    def leaveEvent(self, e):
        self.setStyleSheet(self._normal_style)
    
    def mouseDoubleClickEvent(self, e):
        self.set_val(self.default)
        self.setStyleSheet("color: #00ff00;")
        QTimer.singleShot(200, lambda: self.setStyleSheet(self._normal_style))
        if self.on_reset:
            self.on_reset()


class ToolTip:
    def __init__(self, widget, text_func):
        self.widget = widget
        self.text_func = text_func if callable(text_func) else lambda: text_func
        self._update()
        orig = widget.enterEvent
        def new_enter(e):
            self._update()
            if orig:
                orig(e)
        widget.enterEvent = new_enter
    
    def _update(self):
        self.widget.setToolTip(self.text_func())