import os
import sys
import threading

# Локальные зависимости
app_dir = os.path.dirname(os.path.abspath(__file__))
if app_dir not in sys.path:
    sys.path.insert(0, app_dir)
import setup_paths

from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QPushButton, QLabel, QComboBox, QLineEdit, QCheckBox, QRadioButton,
    QGroupBox, QTabWidget, QTextEdit, QFileDialog, QMessageBox, QProgressBar,
    QButtonGroup, QFrame, QSplitter, QScrollArea, QSizePolicy
)
from PySide6.QtCore import Qt, QTimer, Signal, QObject
from PySide6.QtGui import QFont, QShortcut, QKeySequence

from config_app import (
    APP_DIR, RVC_ROOT, WEIGHTS_DIR, LOGS_DIR,
    INPUT_DIR, OUTPUT_DIR, DEFAULT_SETTINGS, AUDIO_EXTENSIONS,
    OUTPUT_FORMATS, F0_METHODS, CREPE_METHODS_WITH_HOP, PACK_PRESETS,
    load_settings, save_settings
)
from widgets import ScaleWithEntry, ResettableLabel, ToolTip
from presets import PRESET_KEYS, load_presets, save_presets, get_default_presets
from lang import tr

DARK_STYLE = """
QMainWindow, QWidget { background-color: #1e1e2e; color: #cdd6f4; }
QGroupBox { border: 1px solid #45475a; border-radius: 5px; margin-top: 10px; padding-top: 10px; font-weight: bold; }
QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 5px; color: #89b4fa; }
QPushButton { background: #313244; border: 1px solid #45475a; border-radius: 4px; padding: 5px 12px; color: #cdd6f4; }
QPushButton:hover { background: #45475a; }
QPushButton:pressed, QPushButton:checked { background: #585b70; }
QPushButton:disabled { background: #1e1e2e; color: #6c7086; }
QComboBox { background: #313244; border: 1px solid #45475a; border-radius: 4px; padding: 4px 8px; color: #cdd6f4; }
QComboBox:drop-down { border: none; width: 20px; }
QComboBox QAbstractItemView { background: #313244; color: #cdd6f4; selection-background-color: #45475a; }
QLineEdit { background: #313244; border: 1px solid #45475a; border-radius: 4px; padding: 4px 8px; color: #cdd6f4; }
QTextEdit { background: #181825; border: 1px solid #45475a; border-radius: 4px; color: #a6adc8; font-family: Consolas; }
QTabWidget::pane { border: 1px solid #45475a; border-radius: 5px; }
QTabBar::tab { background: #313244; border: 1px solid #45475a; padding: 6px 16px; margin-right: 2px; border-top-left-radius: 4px; border-top-right-radius: 4px; }
QTabBar::tab:selected { background: #45475a; border-bottom-color: #45475a; }
QProgressBar { background: #313244; border: 1px solid #45475a; border-radius: 4px; height: 8px; text-align: center; }
QProgressBar::chunk { background: #89b4fa; border-radius: 3px; }
QCheckBox, QRadioButton { color: #cdd6f4; }
QCheckBox::indicator, QRadioButton::indicator { width: 16px; height: 16px; }
QSlider::groove:horizontal { background: #313244; height: 6px; border-radius: 3px; }
QSlider::handle:horizontal { background: #89b4fa; width: 14px; margin: -4px 0; border-radius: 7px; }
QScrollBar:vertical { background: #1e1e2e; width: 10px; }
QScrollBar::handle:vertical { background: #45475a; border-radius: 5px; min-height: 20px; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
"""


class LogSignal(QObject):
    message = Signal(str)


class RVCConverterGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(tr("RVC Editor"))
        self.setMinimumSize(780, 640)
        
        self.settings = load_settings()
        self.presets = load_presets()
        self._restore_geometry()
        
        self.converter = None
        self.is_converting = False
        self.editor = None
        self.log_signal = LogSignal()
        self.log_signal.message.connect(self._append_log)
        
        self._init_values()
        self._build_ui()
        self._scan_models()
        self._restore_model()
        self._bind_shortcuts()
        
    def _init_values(self):
        s = self.settings
        self.model_path = s.get("model", "")
        self.index_path = s.get("index", "")
        self.input_dir = s.get("input_dir", INPUT_DIR)
        self.output_dir = s.get("output_dir", OUTPUT_DIR)
        self.pitch = s.get("pitch", 0)
        self.f0_method = s.get("f0_method", "rmvpe")
        self.index_rate = s.get("index_rate", 0.90)
        self.filter_radius = s.get("filter_radius", 3)
        self.resample_sr = s.get("resample_sr", 0)
        self.rms_mix_rate = s.get("rms_mix_rate", 0.25)
        self.protect = s.get("protect", 0.33)
        self.crepe_hop_length = s.get("crepe_hop_length", 120)
        self.output_format = s.get("output_format", "wav")
        self.log_visible = s.get("log_visible", False)
        self.preset_load_model = s.get("preset_load_model", False)
        self.preset_load_pitch = s.get("preset_load_pitch", False)
        self.preset_load_f0 = s.get("preset_load_f0", False)
        self.models_list = []
        self.indexes_list = []
    
    def _restore_geometry(self):
        geo = self.settings.get("window_geometry", "")
        state = self.settings.get("window_state", "normal")
        if geo:
            try:
                parts = geo.replace('x', '+').split('+')
                if len(parts) >= 4:
                    self.resize(int(parts[0]), int(parts[1]))
                    self.move(int(parts[2]), int(parts[3]))
            except:
                self.resize(780, 640)
        else:
            self.resize(780, 640)
        if state == "zoomed":
            QTimer.singleShot(100, self.showMaximized)
    
    def _bind_shortcuts(self):
        for i, key in enumerate(PRESET_KEYS):
            QShortcut(QKeySequence(f"F{i+1}"), self, lambda k=key: self._load_preset(k))
        QShortcut(QKeySequence("Ctrl+F1"), self, lambda: self._toggle_preset_opt('model'))
        QShortcut(QKeySequence("Ctrl+F2"), self, lambda: self._toggle_preset_opt('pitch'))
        QShortcut(QKeySequence("Ctrl+F3"), self, lambda: self._toggle_preset_opt('f0'))
    
    def _toggle_preset_opt(self, opt):
        if opt == 'model':
            self.preset_load_model = not self.preset_load_model
            self.cb_load_model.setChecked(self.preset_load_model)
        elif opt == 'pitch':
            self.preset_load_pitch = not self.preset_load_pitch
            self.cb_load_pitch.setChecked(self.preset_load_pitch)
        elif opt == 'f0':
            self.preset_load_f0 = not self.preset_load_f0
            self.cb_load_f0.setChecked(self.preset_load_f0)
    
    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        layout.setContentsMargins(5, 5, 5, 5)
        layout.setSpacing(5)
        
        # Tabs
        self.tabs = QTabWidget()
        layout.addWidget(self.tabs, 1)
        
        editor_tab = QWidget()
        convert_tab = QWidget()
        pack_tab = QWidget()
        
        self.tabs.addTab(editor_tab, f"✂️ {tr('Editor')}")
        self.tabs.addTab(convert_tab, f"🎤 {tr('Conversion')}")
        self.tabs.addTab(pack_tab, f"🎭 {tr('Multi-convert')}")
        
        self._build_editor_tab(editor_tab)
        self._build_convert_tab(convert_tab)
        self._build_pack_tab(pack_tab)
        
        self.tabs.currentChanged.connect(self._on_tab_changed)
        
        # Bottom
        bottom = QHBoxLayout()
        self.progress_label = QLabel(tr("Ready"))
        self.progress_label.setStyleSheet("color: #a6adc8;")
        bottom.addWidget(self.progress_label, 1)
        
        self.log_btn = QPushButton("📋")
        self.log_btn.setFixedWidth(32)
        self.log_btn.clicked.connect(self._toggle_log)
        bottom.addWidget(self.log_btn)
        layout.addLayout(bottom)
        
        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setFixedHeight(8)
        self.progress_bar.setTextVisible(False)
        layout.addWidget(self.progress_bar)
        
        # Log
        self.log_frame = QGroupBox(tr("Log"))
        log_layout = QVBoxLayout(self.log_frame)
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setMaximumHeight(80)
        log_layout.addWidget(self.log_text)
        layout.addWidget(self.log_frame)
        self.log_frame.setVisible(self.log_visible)
    
    def _build_convert_tab(self, parent):
        layout = QVBoxLayout(parent)
        layout.setSpacing(8)
        
        # Model
        model_grp = QGroupBox(tr("Model"))
        model_lay = QGridLayout(model_grp)
        
        model_lay.addWidget(QLabel(tr("Model:")), 0, 0)
        self.model_combo = QComboBox()
        self.model_combo.currentTextChanged.connect(self._on_model_change)
        model_lay.addWidget(self.model_combo, 0, 1)
        
        refresh_btn = QPushButton("🔄")
        refresh_btn.setFixedWidth(32)
        refresh_btn.clicked.connect(self._scan_models)
        model_lay.addWidget(refresh_btn, 0, 2)
        
        model_lay.addWidget(QLabel(tr("Index:")), 1, 0)
        self.index_combo = QComboBox()
        self.index_combo.currentTextChanged.connect(lambda t: setattr(self, 'index_path', t))
        model_lay.addWidget(self.index_combo, 1, 1, 1, 2)
        
        model_lay.setColumnStretch(1, 1)
        layout.addWidget(model_grp)
        
        # Folders
        folder_grp = QGroupBox(tr("Folders"))
        folder_lay = QGridLayout(folder_grp)
        
        folder_lay.addWidget(QLabel(tr("Input:")), 0, 0)
        self.input_edit = QLineEdit(self.input_dir)
        self.input_edit.textChanged.connect(lambda t: setattr(self, 'input_dir', t))
        self.input_edit.textChanged.connect(self._update_files_info)
        folder_lay.addWidget(self.input_edit, 0, 1)
        
        in_btns = QHBoxLayout()
        btn_in_browse = QPushButton("...")
        btn_in_browse.setFixedWidth(32)
        btn_in_browse.clicked.connect(lambda: self._browse_dir('input'))
        in_btns.addWidget(btn_in_browse)
        btn_in_open = QPushButton("📂")
        btn_in_open.setFixedWidth(32)
        btn_in_open.clicked.connect(lambda: self._open_dir(self.input_dir))
        in_btns.addWidget(btn_in_open)
        folder_lay.addLayout(in_btns, 0, 2)
        
        folder_lay.addWidget(QLabel(tr("Output:")), 1, 0)
        self.output_edit = QLineEdit(self.output_dir)
        self.output_edit.textChanged.connect(lambda t: setattr(self, 'output_dir', t))
        folder_lay.addWidget(self.output_edit, 1, 1)
        
        out_btns = QHBoxLayout()
        btn_out_browse = QPushButton("...")
        btn_out_browse.setFixedWidth(32)
        btn_out_browse.clicked.connect(lambda: self._browse_dir('output'))
        out_btns.addWidget(btn_out_browse)
        btn_out_open = QPushButton("📂")
        btn_out_open.setFixedWidth(32)
        btn_out_open.clicked.connect(lambda: self._open_dir(self.output_dir))
        out_btns.addWidget(btn_out_open)
        folder_lay.addLayout(out_btns, 1, 2)
        
        self.files_info = QLabel("")
        self.files_info.setStyleSheet("color: #6c7086;")
        folder_lay.addWidget(self.files_info, 2, 0, 1, 3)
        folder_lay.setColumnStretch(1, 1)
        layout.addWidget(folder_grp)
        self._update_files_info()
        
        # Parameters
        params_grp = QGroupBox(f"{tr('Parameters')}  {tr('(2xclick on label = reset)')}")
        params_lay = QVBoxLayout(params_grp)
        
        # F0 row
        f0_row = QHBoxLayout()
        f0_row.addWidget(ResettableLabel(tr("F0 Method:"), lambda: self.f0_method, 
                         lambda v: self._set_f0(v), DEFAULT_SETTINGS["f0_method"], self._update_f0_btns))
        f0_row.addSpacing(10)
        
        self.f0_btns = {}
        for m in ["rmvpe", "mangio-crepe", "crepe"]:
            btn = QPushButton(m)
            btn.setCheckable(True)
            btn.clicked.connect(lambda _, method=m: self._set_f0(method))
            self.f0_btns[m] = btn
            f0_row.addWidget(btn)
        
        f0_row.addWidget(QLabel(f"  {tr('or')} "))
        self.f0_other = QComboBox()
        self.f0_other.addItems([m for m in F0_METHODS if m not in ["rmvpe", "mangio-crepe", "crepe"]])
        self.f0_other.setFixedWidth(120)
        self.f0_other.currentTextChanged.connect(lambda t: t and self._set_f0(t))
        f0_row.addWidget(self.f0_other)
        f0_row.addStretch()
        params_lay.addLayout(f0_row)
        
        # Crepe hop
        self.crepe_frame = QWidget()
        crepe_lay = QHBoxLayout(self.crepe_frame)
        crepe_lay.setContentsMargins(0, 0, 0, 0)
        crepe_lay.addWidget(ResettableLabel(tr("Analysis step:"), lambda: self.crepe_hop_length,
                           lambda v: setattr(self, 'crepe_hop_length', int(v)), DEFAULT_SETTINGS["crepe_hop_length"]))
        crepe_lay.addSpacing(10)
        self.crepe_scale = ScaleWithEntry(lambda: self.crepe_hop_length, 
                                          lambda v: setattr(self, 'crepe_hop_length', int(v)), 16, 512, 1, 50, 150)
        crepe_lay.addWidget(self.crepe_scale)
        crepe_lay.addWidget(QLabel(f"  {tr('(less = more accurate)')}"))
        crepe_lay.addStretch()
        params_lay.addWidget(self.crepe_frame)
        
        # Separator
        sep = QFrame()
        sep.setFrameShape(QFrame.HLine)
        sep.setStyleSheet("background: #45475a;")
        params_lay.addWidget(sep)
        
        # Grid params
        grid = QGridLayout()
        grid.setSpacing(10)
        
        # Row 0
        grid.addWidget(ResettableLabel(tr("Pitch:"), lambda: self.pitch,
                       lambda v: setattr(self, 'pitch', int(v)), DEFAULT_SETTINGS["pitch"]), 0, 0)
        pitch_btns = QHBoxLayout()
        for val, txt in [(-12, "-12"), (0, "0"), (12, "+12")]:
            btn = QPushButton(txt)
            btn.setFixedWidth(40)
            btn.clicked.connect(lambda _, v=val: self._set_pitch(v))
            pitch_btns.addWidget(btn)
        grid.addLayout(pitch_btns, 0, 1)
        self.pitch_scale = ScaleWithEntry(lambda: self.pitch, lambda v: setattr(self, 'pitch', int(v)), -24, 24, 1, 50, 115)
        grid.addWidget(self.pitch_scale, 0, 2)
        
        grid.addWidget(ResettableLabel(tr("Pitch filter:"), lambda: self.filter_radius,
                       lambda v: setattr(self, 'filter_radius', int(v)), DEFAULT_SETTINGS["filter_radius"]), 0, 3)
        self.filter_scale = ScaleWithEntry(lambda: self.filter_radius, lambda v: setattr(self, 'filter_radius', int(v)), 0, 7, 1, 50, 115)
        grid.addWidget(self.filter_scale, 0, 4)
        
        # Row 1
        grid.addWidget(ResettableLabel(tr("Index influence:"), lambda: self.index_rate,
                       lambda v: setattr(self, 'index_rate', v), DEFAULT_SETTINGS["index_rate"]), 1, 0)
        self.index_scale = ScaleWithEntry(lambda: self.index_rate, lambda v: setattr(self, 'index_rate', v), 0, 1, 0.01, 50, 115)
        grid.addWidget(self.index_scale, 1, 2)
        
        grid.addWidget(ResettableLabel(tr("Volume mix:"), lambda: self.rms_mix_rate,
                       lambda v: setattr(self, 'rms_mix_rate', v), DEFAULT_SETTINGS["rms_mix_rate"]), 1, 3)
        self.rms_scale = ScaleWithEntry(lambda: self.rms_mix_rate, lambda v: setattr(self, 'rms_mix_rate', v), 0, 1, 0.01, 50, 115)
        grid.addWidget(self.rms_scale, 1, 4)
        
        # Row 2
        grid.addWidget(ResettableLabel(tr("Consonant protection:"), lambda: self.protect,
                       lambda v: setattr(self, 'protect', v), DEFAULT_SETTINGS["protect"]), 2, 0)
        self.protect_scale = ScaleWithEntry(lambda: self.protect, lambda v: setattr(self, 'protect', v), 0, 0.5, 0.01, 50, 115)
        grid.addWidget(self.protect_scale, 2, 2)
        
        grid.addWidget(ResettableLabel(tr("Resample:"), lambda: self.resample_sr,
                       lambda v: setattr(self, 'resample_sr', int(v)), DEFAULT_SETTINGS["resample_sr"]), 2, 3)
        self.resample_combo = QComboBox()
        self.resample_combo.addItems(["0", "16000", "22050", "32000", "44100", "48000"])
        self.resample_combo.setCurrentText(str(self.resample_sr))
        self.resample_combo.currentTextChanged.connect(lambda t: setattr(self, 'resample_sr', int(t or 0)))
        grid.addWidget(self.resample_combo, 2, 4)
        
        params_lay.addLayout(grid)
        
        # Presets row
        preset_row = QHBoxLayout()
        reset_presets_btn = QPushButton("↺")
        reset_presets_btn.setFixedWidth(28)
        reset_presets_btn.setToolTip(tr("Reset presets to default"))
        reset_presets_btn.clicked.connect(self._reset_presets)
        preset_row.addWidget(reset_presets_btn)
        preset_row.addWidget(QLabel(tr("Presets:")))
        
        self.preset_btns = {}
        for key in PRESET_KEYS:
            btn = QPushButton(key)
            btn.setFixedWidth(36)
            btn.clicked.connect(lambda _, k=key: self._save_preset(k))
            ToolTip(btn, lambda k=key: self._get_preset_tooltip(k))
            self.preset_btns[key] = btn
            preset_row.addWidget(btn)
        preset_row.addStretch()
        params_lay.addLayout(preset_row)
        
        # Preset options
        opt_row = QHBoxLayout()
        opt_row.addWidget(QLabel(tr("On load (F1-F12):")))
        self.cb_load_model = QCheckBox(tr("Model"))
        self.cb_load_model.setChecked(self.preset_load_model)
        self.cb_load_model.toggled.connect(lambda v: setattr(self, 'preset_load_model', v))
        opt_row.addWidget(self.cb_load_model)
        
        self.cb_load_pitch = QCheckBox(tr("Tone"))
        self.cb_load_pitch.setChecked(self.preset_load_pitch)
        self.cb_load_pitch.toggled.connect(lambda v: setattr(self, 'preset_load_pitch', v))
        opt_row.addWidget(self.cb_load_pitch)
        
        self.cb_load_f0 = QCheckBox(tr("F0 method"))
        self.cb_load_f0.setChecked(self.preset_load_f0)
        self.cb_load_f0.toggled.connect(lambda v: setattr(self, 'preset_load_f0', v))
        opt_row.addWidget(self.cb_load_f0)
        opt_row.addStretch()
        params_lay.addLayout(opt_row)
        
        # Bottom params
        bottom_row = QHBoxLayout()
        reset_btn = QPushButton("↺")
        reset_btn.setFixedWidth(28)
        reset_btn.clicked.connect(self._reset_all_params)
        bottom_row.addWidget(reset_btn)
        bottom_row.addWidget(QLabel(tr("Format:")))
        
        self.format_group = QButtonGroup(self)
        for fmt in OUTPUT_FORMATS:
            rb = QRadioButton(fmt.upper())
            rb.setChecked(fmt == self.output_format)
            rb.toggled.connect(lambda checked, f=fmt: checked and setattr(self, 'output_format', f))
            self.format_group.addButton(rb)
            bottom_row.addWidget(rb)
        
        bottom_row.addStretch()
        self.convert_btn = QPushButton(f"🎤 {tr('Convert')}")
        self.convert_btn.setStyleSheet("background: #89b4fa; color: #1e1e2e; font-weight: bold;")
        self.convert_btn.clicked.connect(self._convert)
        bottom_row.addWidget(self.convert_btn)
        params_lay.addLayout(bottom_row)
        
        layout.addWidget(params_grp, 1)
        
        self._update_f0_btns()
        self._update_crepe_visible()
    
    def _build_pack_tab(self, parent):
        layout = QVBoxLayout(parent)
        
        layout.addWidget(QLabel(tr("Convert files from folder with different parameters")))
        info = QLabel(tr("Folders, pitch and format from 'Conversion' tab"))
        info.setStyleSheet("color: #6c7086;")
        layout.addWidget(info)
        
        presets_grp = QGroupBox(tr("Presets (Index rate / Protect)"))
        presets_lay = QGridLayout(presets_grp)
        
        saved = self.settings.get("pack_presets", [True] * len(PACK_PRESETS))
        self.pack_vars = []
        
        for i, preset in enumerate(PACK_PRESETS):
            var = saved[i] if i < len(saved) else True
            cb = QCheckBox(f"{tr(preset['name'])}: I={preset['index_rate']:.2f}, P={preset['protect']:.2f}")
            cb.setChecked(var)
            self.pack_vars.append(cb)
            presets_lay.addWidget(cb, i % 4, i // 4)
        
        sel_row = QHBoxLayout()
        sel_all = QPushButton(tr("Select all"))
        sel_all.clicked.connect(lambda: [cb.setChecked(True) for cb in self.pack_vars])
        sel_row.addWidget(sel_all)
        desel_all = QPushButton(tr("Deselect all"))
        desel_all.clicked.connect(lambda: [cb.setChecked(False) for cb in self.pack_vars])
        sel_row.addWidget(desel_all)
        sel_row.addStretch()
        presets_lay.addLayout(sel_row, 4, 0, 1, 3)
        
        layout.addWidget(presets_grp)
        
        fixed_grp = QGroupBox(tr("Fixed parameters"))
        fixed_lay = QVBoxLayout(fixed_grp)
        fixed_lay.addWidget(QLabel("F0: rmvpe  •  Filter: 3  •  RMS: 0.25  •  Resample: off"))
        layout.addWidget(fixed_grp)
        
        self.pack_btn = QPushButton(f"🎭 {tr('Run multi-convert')}")
        self.pack_btn.setStyleSheet("background: #a6e3a1; color: #1e1e2e; font-weight: bold;")
        self.pack_btn.clicked.connect(self._pack_convert)
        layout.addWidget(self.pack_btn)
        layout.addStretch()
    
    def _build_editor_tab(self, parent):
        from editor import EditorTab
        layout = QVBoxLayout(parent)
        layout.setContentsMargins(0, 0, 0, 0)
        self.editor = EditorTab(
            parent, self._get_converter_for_editor, self.log, self.set_progress,
            lambda: self.output_dir, lambda: self.settings.get("editor_file", ""),
            self._set_editor_file, self._get_preset_info,
            self.settings.get("blend_mode", 0)
        )
        layout.addWidget(self.editor)
    
    def _on_tab_changed(self, idx):
        if self.editor:
            if idx == 0:
                self.editor.on_tab_activated()
            else:
                self.editor.on_tab_deactivated()
    
    def _set_f0(self, method):
        self.f0_method = method
        self._update_f0_btns()
        self._update_crepe_visible()
        if self.editor:
            self.editor.update_preset_display()
    
    def _update_f0_btns(self):
        for m, btn in self.f0_btns.items():
            btn.setChecked(m == self.f0_method)
        if self.f0_method in self.f0_btns:
            self.f0_other.setCurrentIndex(-1)
        else:
            idx = self.f0_other.findText(self.f0_method)
            if idx >= 0:
                self.f0_other.setCurrentIndex(idx)
    
    def _update_crepe_visible(self):
        self.crepe_frame.setVisible(self.f0_method in CREPE_METHODS_WITH_HOP)
    
    def _set_pitch(self, val):
        self.pitch = val
        self.pitch_scale.refresh()
    
    def _scan_models(self):
        self.models_list, self.indexes_list = [], []
        if os.path.exists(WEIGHTS_DIR):
            self.models_list = [f for f in os.listdir(WEIGHTS_DIR) if f.endswith(".pth")]
        for root, _, files in os.walk(LOGS_DIR):
            for f in files:
                if f.endswith(".index") and "trained" not in f:
                    self.indexes_list.append(os.path.relpath(os.path.join(root, f), RVC_ROOT))
        
        self.model_combo.clear()
        self.model_combo.addItems(sorted(self.models_list))
        self.index_combo.clear()
        self.index_combo.addItems(["(no index)"] + sorted(self.indexes_list))
        self.log(f"{tr('Models:')} {len(self.models_list)}, {tr('indexes:')} {len(self.indexes_list)}")
    
    def _restore_model(self):
        saved = self.settings.get("model", "")
        if saved and saved in self.models_list:
            self.model_combo.setCurrentText(saved)
        saved_idx = self.settings.get("index", "")
        if saved_idx and saved_idx in self.indexes_list:
            self.index_combo.setCurrentText(saved_idx)
    
    def _on_model_change(self, name):
        self.model_path = name
        if not name:
            return
        base = os.path.splitext(name)[0].lower()
        best, score = "", 0
        for idx in self.indexes_list:
            if base in idx.lower():
                s = len(base) + (10 if "added" in idx.lower() else 0)
                if s > score:
                    score, best = s, idx
        if best:
            self.index_combo.setCurrentText(best)
            self.index_path = best
        if self.editor:
            self.editor.update_preset_display()
    
    def _update_files_info(self):
        if os.path.exists(self.input_dir):
            files = [f for f in os.listdir(self.input_dir) if f.lower().endswith(AUDIO_EXTENSIONS)]
            self.files_info.setText(f"{tr('Audio files found:')} {len(files)}")
        else:
            self.files_info.setText(tr("Folder does not exist"))
    
    def _browse_dir(self, which):
        cur = self.input_dir if which == 'input' else self.output_dir
        path = QFileDialog.getExistingDirectory(self, tr("Select folder"), cur)
        if path:
            if which == 'input':
                self.input_dir = path
                self.input_edit.setText(path)
            else:
                self.output_dir = path
                self.output_edit.setText(path)
    
    def _open_dir(self, path):
        os.makedirs(path, exist_ok=True)
        os.startfile(path)
    
    def _reset_all_params(self):
        d = DEFAULT_SETTINGS
        self.pitch = d["pitch"]
        self.f0_method = d["f0_method"]
        self.index_rate = d["index_rate"]
        self.filter_radius = d["filter_radius"]
        self.resample_sr = d["resample_sr"]
        self.rms_mix_rate = d["rms_mix_rate"]
        self.protect = d["protect"]
        self.crepe_hop_length = d["crepe_hop_length"]
        
        for scale in [self.pitch_scale, self.filter_scale, self.index_scale, 
                      self.rms_scale, self.protect_scale, self.crepe_scale]:
            scale.refresh()
        self.resample_combo.setCurrentText("0")
        self._update_f0_btns()
        self._update_crepe_visible()
        self.log(tr("Parameters reset"))
    
    def _get_preset_tooltip(self, key):
        if key not in self.presets:
            return f"{key}: {tr('is empty')}\n{tr('click = save')}"
        p = self.presets[key]
        model = os.path.splitext(p.get("model", ""))[0] or tr("(no model)")
        return f"{key}: {model}\nPitch: {p.get('pitch', 0):+d}, F0: {p.get('f0_method', '?')}\n{tr('click = overwrite')}"
    
    def _save_preset(self, key):
        if not self.model_path:
            self.log(tr("First select a model"))
            return
        self.presets[key] = {
            "model": self.model_path, "index": self.index_path, "pitch": self.pitch,
            "f0_method": self.f0_method, "index_rate": self.index_rate,
            "filter_radius": self.filter_radius, "resample_sr": self.resample_sr,
            "rms_mix_rate": self.rms_mix_rate, "protect": self.protect,
            "crepe_hop_length": self.crepe_hop_length, "output_format": self.output_format
        }
        save_presets(self.presets)
        self.log(f"{tr('Preset')} {key} {tr('saved')}")
    
    def _load_preset(self, key):
        if key not in self.presets:
            self.log(f"{tr('Preset')} {key} {tr('is empty')}")
            return
        
        p = self.presets[key]
        need_reload = False
        
        if self.preset_load_model:
            new_model = p.get("model", "")
            if new_model and new_model in self.models_list:
                if new_model != self.model_path:
                    need_reload = True
                self.model_combo.setCurrentText(new_model)
                if p.get("index"):
                    self.index_combo.setCurrentText(p["index"])
        
        if self.preset_load_pitch:
            self.pitch = p.get("pitch", 0)
            self.pitch_scale.refresh()
        
        if self.preset_load_f0:
            self._set_f0(p.get("f0_method", "rmvpe"))
            self.crepe_hop_length = p.get("crepe_hop_length", 120)
            self.crepe_scale.refresh()
        
        self.index_rate = p.get("index_rate", 0.9)
        self.filter_radius = p.get("filter_radius", 3)
        self.resample_sr = p.get("resample_sr", 0)
        self.rms_mix_rate = p.get("rms_mix_rate", 0.25)
        self.protect = p.get("protect", 0.33)
        self.output_format = p.get("output_format", "wav")
        
        for scale in [self.index_scale, self.filter_scale, self.rms_scale, self.protect_scale]:
            scale.refresh()
        self.resample_combo.setCurrentText(str(self.resample_sr))
        
        if need_reload and self.converter and self.converter.is_initialized:
            self._ensure_model_loaded()
        
        self.log(f"{tr('Preset')} {key} {tr('loaded')}")
        
        if self.tabs.currentIndex() == 0 and self.editor:
            self.editor.on_preset_loaded()
    
    def _reset_presets(self):
        self.presets = get_default_presets()
        save_presets(self.presets)
        self.log(tr("Presets reset to default"))
    
    def _toggle_log(self):
        self.log_visible = not self.log_visible
        self.log_frame.setVisible(self.log_visible)
    
    def log(self, msg):
        self.log_signal.message.emit(str(msg))
    
    def _append_log(self, msg):
        self.log_text.append(msg)
    
    def set_progress(self, val, text=""):
        self.progress_bar.setValue(int(val))
        if text:
            self.progress_label.setText(text[:30])
    
    def _set_buttons_state(self, enabled):
        self.convert_btn.setEnabled(enabled)
        self.pack_btn.setEnabled(enabled)
    
    def _ensure_model_loaded(self):
        if not self.model_path:
            self.log(tr("Error: model not selected"))
            return False
        
        index_path = ""
        if self.index_path and self.index_path != "(no index)":
            index_path = os.path.join(RVC_ROOT, self.index_path)
        
        if self.converter is None:
            from converter import VoiceConverter
            self.converter = VoiceConverter(self.set_progress, self.log)
        
        if self.converter.is_model_loaded(self.model_path, index_path):
            return True
        
        if not self.converter.initialize():
            return False
        return self.converter.load_model(os.path.join(WEIGHTS_DIR, self.model_path), index_path)
    
    def _get_convert_params(self):
        index_path = ""
        if self.index_path and self.index_path != "(no index)":
            index_path = os.path.join(RVC_ROOT, self.index_path)
        return {
            "pitch": self.pitch, "f0_method": self.f0_method, "index_path": index_path,
            "index_rate": self.index_rate, "filter_radius": self.filter_radius,
            "resample_sr": self.resample_sr, "rms_mix_rate": self.rms_mix_rate,
            "protect": self.protect, "crepe_hop_length": self.crepe_hop_length,
            "output_format": self.output_format
        }
    
    def _get_preset_info(self):
        return {
            "model": self.model_path, "f0_method": self.f0_method, "pitch": self.pitch,
            "index_rate": self.index_rate, "filter_radius": self.filter_radius,
            "resample_sr": self.resample_sr, "rms_mix_rate": self.rms_mix_rate,
            "protect": self.protect, "crepe_hop_length": self.crepe_hop_length
        }
    
    def _get_converter_for_editor(self):
        if not self._ensure_model_loaded():
            return None, {}
        return self.converter, self._get_convert_params()
    
    def _set_editor_file(self, path):
        self.settings["editor_file"] = path
        self._save_settings()
    
    def _convert(self):
        if not os.path.exists(self.input_dir):
            QMessageBox.warning(self, tr("Warning"), tr("Input folder does not exist"))
            return
        if self.is_converting:
            return
        
        def work():
            self.is_converting = True
            self._set_buttons_state(False)
            try:
                os.makedirs(self.output_dir, exist_ok=True)
                if not self._ensure_model_loaded():
                    QMessageBox.critical(self, tr("Error"), tr("Failed to load model"))
                    return
                results = self.converter.convert_folder(self.input_dir, self.output_dir, **self._get_convert_params())
                if results:
                    ok = sum(1 for _, _, s in results if s)
                    self.log(f"✓ {tr('Done:')} {ok}/{len(results)}")
            except Exception as e:
                self.log(f"{tr('Error:')} {e}")
            finally:
                self.is_converting = False
                self._set_buttons_state(True)
                self._save_settings()
        
        threading.Thread(target=work, daemon=True).start()
    
    def _pack_convert(self):
        if not os.path.exists(self.input_dir):
            QMessageBox.warning(self, tr("Warning"), tr("Input folder does not exist"))
            return
        if self.is_converting:
            return
        
        presets = [PACK_PRESETS[i] for i, cb in enumerate(self.pack_vars) if cb.isChecked()]
        if not presets:
            QMessageBox.warning(self, tr("Warning"), tr("Select at least one preset"))
            return
        
        def work():
            self.is_converting = True
            self._set_buttons_state(False)
            try:
                if not self._ensure_model_loaded():
                    QMessageBox.critical(self, tr("Error"), tr("Failed to load model"))
                    return
                params = self._get_convert_params()
                params["f0_method"] = "rmvpe"
                params["filter_radius"] = 3
                params["resample_sr"] = 0
                params["rms_mix_rate"] = 0.25
                
                results = self.converter.convert_pack(self.input_dir, self.output_dir, presets, **params)
                if results:
                    ok = sum(1 for r in results if r["success"])
                    self.log(f"✓ {tr('Done:')} {ok}/{len(results)}")
            except Exception as e:
                self.log(f"{tr('Error:')} {e}")
            finally:
                self.is_converting = False
                self._set_buttons_state(True)
                self._save_settings()
        
        threading.Thread(target=work, daemon=True).start()
    
    def _save_settings(self):
        geo = f"{self.width()}x{self.height()}+{self.x()}+{self.y()}"
        state = "zoomed" if self.isMaximized() else "normal"
        
        self.settings.update({
            "model": self.model_path, "index": self.index_path,
            "input_dir": self.input_dir, "output_dir": self.output_dir,
            "pitch": self.pitch, "f0_method": self.f0_method,
            "index_rate": self.index_rate, "filter_radius": self.filter_radius,
            "resample_sr": self.resample_sr, "rms_mix_rate": self.rms_mix_rate,
            "protect": self.protect, "crepe_hop_length": self.crepe_hop_length,
            "output_format": self.output_format, "log_visible": self.log_visible,
            "pack_presets": [cb.isChecked() for cb in self.pack_vars],
            "window_geometry": geo, "window_state": state,
            "preset_load_model": self.preset_load_model,
            "preset_load_pitch": self.preset_load_pitch,
            "preset_load_f0": self.preset_load_f0,
            "blend_mode": self.editor.blend_mode if self.editor else 0
        })
        save_settings(self.settings)
    
    def closeEvent(self, e):
        if self.editor:
            self.editor.cleanup()
        self._save_settings()
        e.accept()


def main():
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    app.setStyleSheet(DARK_STYLE)
    
    window = RVCConverterGUI()
    window.show()
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()