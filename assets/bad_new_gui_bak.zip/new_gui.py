import sys
import os

# Добавляем текущую папку в путь поиска ПЕРЕД импортом setup_paths
app_dir = os.path.dirname(os.path.abspath(__file__))
if app_dir not in sys.path:
    sys.path.insert(0, app_dir)

# Теперь импортируем setup_paths
import setup_paths

import numpy as np

from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QSlider, QFileDialog, QGroupBox, QComboBox,
    QStatusBar, QSplitter, QFrame
)
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QFont

import pyqtgraph as pg

# Настройка pyqtgraph
pg.setConfigOptions(antialias=True, background='w', foreground='k')


class WaveformWidget(pg.PlotWidget):
    """Виджет для отображения формы волны"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.setLabel('left', 'Амплитуда')
        self.setLabel('bottom', 'Время', units='сек')
        self.showGrid(x=True, y=True, alpha=0.3)
        self.setMouseEnabled(x=True, y=False)
        
        # Линия формы волны
        self.waveform_curve = self.plot([], [], pen=pg.mkPen('#2196F3', width=1))
        
        # Линия позиции воспроизведения
        self.position_line = pg.InfiniteLine(
            pos=0, angle=90, 
            pen=pg.mkPen('#F44336', width=2),
            movable=False
        )
        self.addItem(self.position_line)
        self.position_line.hide()
        
        # Регион выделения
        self.selection_region = pg.LinearRegionItem(
            values=[0, 1],
            brush=pg.mkBrush(33, 150, 243, 50),
            pen=pg.mkPen('#2196F3', width=2)
        )
        self.addItem(self.selection_region)
        self.selection_region.hide()
    
    def set_waveform(self, samples, sample_rate):
        """Установить форму волны"""
        if len(samples) == 0:
            return
        
        # Децимация для быстрого отображения
        max_points = 50000
        if len(samples) > max_points:
            step = len(samples) // max_points
            samples = samples[::step]
            effective_sr = sample_rate / step
        else:
            effective_sr = sample_rate
        
        time = np.arange(len(samples)) / effective_sr
        self.waveform_curve.setData(time, samples)
        self.setXRange(0, time[-1], padding=0.02)
        
        max_amp = max(abs(samples.min()), abs(samples.max())) * 1.1
        self.setYRange(-max_amp, max_amp)
    
    def set_position(self, time_sec):
        """Установить позицию воспроизведения"""
        self.position_line.setPos(time_sec)
        self.position_line.show()
    
    def show_selection(self, start, end):
        """Показать регион выделения"""
        self.selection_region.setRegion([start, end])
        self.selection_region.show()
    
    def clear_all(self):
        """Очистить все"""
        self.waveform_curve.setData([], [])
        self.position_line.hide()
        self.selection_region.hide()


class SpectrogramWidget(pg.PlotWidget):
    """Виджет для отображения спектрограммы"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.setLabel('left', 'Частота', units='Гц')
        self.setLabel('bottom', 'Время', units='сек')
        
        # ImageItem для спектрограммы
        self.img = pg.ImageItem()
        self.addItem(self.img)
        
        # Цветовая карта
        colormap = pg.colormap.get('viridis')
        self.img.setColorMap(colormap)
        
    def set_spectrogram(self, spec_data, time_axis, freq_axis):
        """Установить данные спектрограммы"""
        self.img.setImage(spec_data.T)
        
        # Масштабирование
        x_scale = time_axis[-1] / spec_data.shape[0] if spec_data.shape[0] > 0 else 1
        y_scale = freq_axis[-1] / spec_data.shape[1] if spec_data.shape[1] > 0 else 1
        
        self.img.setTransform(pg.QtGui.QTransform().scale(x_scale, y_scale))
        self.setXRange(0, time_axis[-1], padding=0.02)
        self.setYRange(0, freq_axis[-1], padding=0.02)
    
    def clear_all(self):
        """Очистить"""
        self.img.clear()


class RVCNewGUI(QMainWindow):
    """Главное окно приложения"""
    
    def __init__(self):
        super().__init__()
        
        self.setWindowTitle("RVC Editor (PySide6 + pyqtgraph)")
        self.setMinimumSize(900, 600)
        self.resize(1100, 700)
        
        # Данные
        self.audio_data = None
        self.sample_rate = 44100
        self.current_file = None
        
        self._init_ui()
        self._generate_demo_data()
        
    def _init_ui(self):
        """Инициализация интерфейса"""
        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(10)
        
        # === Верхняя панель управления ===
        controls = QHBoxLayout()
        
        # Кнопки файла
        file_group = QGroupBox("Файл")
        file_layout = QHBoxLayout(file_group)
        
        self.btn_open = QPushButton("📂 Открыть")
        self.btn_open.clicked.connect(self._open_file)
        file_layout.addWidget(self.btn_open)
        
        self.btn_save = QPushButton("💾 Сохранить")
        self.btn_save.setEnabled(False)
        file_layout.addWidget(self.btn_save)
        
        controls.addWidget(file_group)
        
        # Параметры
        params_group = QGroupBox("Параметры")
        params_layout = QHBoxLayout(params_group)
        
        params_layout.addWidget(QLabel("Pitch:"))
        self.pitch_slider = QSlider(Qt.Horizontal)
        self.pitch_slider.setRange(-24, 24)
        self.pitch_slider.setValue(0)
        self.pitch_slider.setFixedWidth(150)
        self.pitch_slider.valueChanged.connect(self._on_pitch_change)
        params_layout.addWidget(self.pitch_slider)
        
        self.pitch_label = QLabel("0")
        self.pitch_label.setFixedWidth(30)
        params_layout.addWidget(self.pitch_label)
        
        params_layout.addWidget(QLabel("F0:"))
        self.f0_combo = QComboBox()
        self.f0_combo.addItems(["rmvpe", "crepe", "mangio-crepe", "harvest", "pm"])
        self.f0_combo.setFixedWidth(120)
        params_layout.addWidget(self.f0_combo)
        
        controls.addWidget(params_group)
        
        # Кнопки действий
        action_group = QGroupBox("Действия")
        action_layout = QHBoxLayout(action_group)
        
        self.btn_convert = QPushButton("🎤 Конвертировать")
        self.btn_convert.setStyleSheet("background-color: #4CAF50; color: white; font-weight: bold;")
        self.btn_convert.setEnabled(False)
        action_layout.addWidget(self.btn_convert)
        
        self.btn_play = QPushButton("▶ Воспроизвести")
        self.btn_play.setEnabled(False)
        action_layout.addWidget(self.btn_play)
        
        controls.addWidget(action_group)
        controls.addStretch()
        
        layout.addLayout(controls)
        
        # === Графики ===
        splitter = QSplitter(Qt.Vertical)
        
        # Форма волны
        wave_frame = QFrame()
        wave_frame.setFrameStyle(QFrame.StyledPanel)
        wave_layout = QVBoxLayout(wave_frame)
        wave_layout.setContentsMargins(5, 5, 5, 5)
        
        wave_label = QLabel("Форма волны")
        wave_label.setFont(QFont("Segoe UI", 10, QFont.Bold))
        wave_layout.addWidget(wave_label)
        
        self.waveform = WaveformWidget()
        wave_layout.addWidget(self.waveform)
        
        splitter.addWidget(wave_frame)
        
        # Спектрограмма
        spec_frame = QFrame()
        spec_frame.setFrameStyle(QFrame.StyledPanel)
        spec_layout = QVBoxLayout(spec_frame)
        spec_layout.setContentsMargins(5, 5, 5, 5)
        
        spec_label = QLabel("Спектрограмма")
        spec_label.setFont(QFont("Segoe UI", 10, QFont.Bold))
        spec_layout.addWidget(spec_label)
        
        self.spectrogram = SpectrogramWidget()
        spec_layout.addWidget(self.spectrogram)
        
        splitter.addWidget(spec_frame)
        
        # Соотношение размеров
        splitter.setSizes([300, 200])
        
        layout.addWidget(splitter, stretch=1)
        
        # === Статусбар ===
        self.statusbar = QStatusBar()
        self.setStatusBar(self.statusbar)
        self.statusbar.showMessage("Готово. Откройте аудиофайл или используйте демо-данные.")
        
    def _generate_demo_data(self):
        """Генерация демо-данных для проверки работы"""
        duration = 5.0  # секунды
        sr = 44100
        t = np.linspace(0, duration, int(sr * duration))
        
        # Сложный сигнал
        freq1, freq2, freq3 = 440, 880, 1320
        signal = (
            0.5 * np.sin(2 * np.pi * freq1 * t) +
            0.3 * np.sin(2 * np.pi * freq2 * t) +
            0.2 * np.sin(2 * np.pi * freq3 * t)
        )
        
        # Добавляем модуляцию
        envelope = np.exp(-t / 3) * (1 + 0.3 * np.sin(2 * np.pi * 2 * t))
        signal = signal * envelope
        
        # Добавляем немного шума
        signal += 0.02 * np.random.randn(len(signal))
        
        self.audio_data = signal.astype(np.float32)
        self.sample_rate = sr
        
        # Отображаем форму волны
        self.waveform.set_waveform(self.audio_data, self.sample_rate)
        
        # Генерируем простую спектрограмму
        self._update_spectrogram()
        
        self.statusbar.showMessage("Загружены демо-данные (5 сек, 44100 Hz)")
        
    def _update_spectrogram(self):
        """Обновление спектрограммы"""
        if self.audio_data is None:
            return
        
        # Простая STFT
        window_size = 2048
        hop = 512
        n_frames = (len(self.audio_data) - window_size) // hop + 1
        
        if n_frames <= 0:
            return
        
        spec = np.zeros((n_frames, window_size // 2))
        window = np.hanning(window_size)
        
        for i in range(n_frames):
            start = i * hop
            frame = self.audio_data[start:start + window_size] * window
            fft = np.fft.rfft(frame)
            spec[i] = 20 * np.log10(np.abs(fft[:-1]) + 1e-10)
        
        # Нормализация
        spec = np.clip(spec, -80, 0)
        spec = (spec + 80) / 80
        
        time_axis = np.linspace(0, len(self.audio_data) / self.sample_rate, n_frames)
        freq_axis = np.linspace(0, self.sample_rate / 2, window_size // 2)
        
        self.spectrogram.set_spectrogram(spec, time_axis, freq_axis)
    
    def _open_file(self):
        """Открыть аудиофайл"""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Открыть аудиофайл",
            "",
            "Audio Files (*.wav *.mp3 *.flac *.ogg);;All Files (*.*)"
        )
        
        if file_path:
            self.current_file = file_path
            self.statusbar.showMessage(f"Файл: {os.path.basename(file_path)}")
            self.btn_convert.setEnabled(True)
            self.btn_play.setEnabled(True)
            self.btn_save.setEnabled(True)
            
            # TODO: Реальная загрузка аудио
            # Пока используем демо-данные
            self._generate_demo_data()
    
    def _on_pitch_change(self, value):
        """Изменение pitch"""
        self.pitch_label.setText(f"{value:+d}" if value != 0 else "0")


def main():
    # Проверка зависимостей
    deps = setup_paths.check_deps()
    
    missing = [name for name, ver in deps.items() if ver is None]
    if missing:
        print(f"[!] Отсутствуют зависимости: {', '.join(missing)}")
        print("    Запустите install_deps.bat")
        input("Нажмите Enter для выхода...")
        sys.exit(1)
    
    print(f"PySide6: {deps['PySide6']}")
    print(f"pyqtgraph: {deps['pyqtgraph']}")
    
    # Создаём приложение
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    
    # Тема
    app.setStyleSheet("""
        QMainWindow {
            background-color: #f5f5f5;
        }
        QGroupBox {
            font-weight: bold;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-top: 10px;
            padding-top: 10px;
        }
        QGroupBox::title {
            subcontrol-origin: margin;
            left: 10px;
            padding: 0 5px;
        }
        QPushButton {
            padding: 5px 15px;
            border-radius: 3px;
        }
        QPushButton:hover {
            background-color: #e0e0e0;
        }
    """)
    
    window = RVCNewGUI()
    window.show()
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()